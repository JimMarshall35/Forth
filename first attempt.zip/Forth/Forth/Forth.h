/*

Forth interpreter - � Jim Marshall 2022

Loosly based on this youtubers videos on writing a forth interpreter: Thanks!
https://www.youtube.com/@JoeKreydt

Example forth code for doing fibonacci sequence

: fib
	twodup
	+
;

: fibLoop
	0 do
		fib show
	loop
;

: computeFib
	0 1 ( first two values of fibonacci series )
	rot ( rotate to get the users number on the top of the stack for the do loop )
	fibLoop
;

*/
#ifndef FORTH
#define FORTH
#ifdef __cplusplus
extern "C" {
#endif
	typedef void* (*AllocateHeap)(int numBytes);
	typedef void (*FreeHeap)(void* memory);
	typedef void (*ReallocateHeap)(void* memory, int numBytes);
	typedef int (*ForthPrintf)(const char* format, ...);
	typedef int (*ForthPrintf)(const char* format, ...);
	typedef int (*ForthPutChar)(int val);
	typedef enum {
		Undefined,
		StringDoneOkay,
		RuntimeError,
		ExitRepl,
		TokenDoneOkay,
		HelperDoneOkay,
		CompileError,
		ExecutionPositionChangedByWord,
		WordNotFound
	}ForthDoStringResult;
	void Forth_Initialise(AllocateHeap allocator, FreeHeap freeAllocated, ReallocateHeap reallocate, ForthPrintf printf, ForthPutChar val);
	void Forth_Teardown();
	ForthDoStringResult Forth_DoString(const char* inputString, int* numTokens);


#ifdef __cplusplus
} // closing brace for extern "C"
#endif
#endif