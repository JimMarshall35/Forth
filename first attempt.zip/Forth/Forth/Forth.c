#include "Forth.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>

/*

bytecode version WIP

Forth interpreter - � Jim Marshall 2022

Loosly based on this youtubers videos on writing a forth interpreter: Thanks!
https://www.youtube.com/@JoeKreydt

Example forth code for doing fibonacci sequence

: fib
	twodup
	+
;

: fibLoop
	0 do
		fib
		rot
		pop
		dup
		.
	loop
;

: computeFib
	0 1
	rot ( rotate to get the users number on the top of the stack for the do loop )
	fibLoop
;

fizz buzz

: cr 10 emit ;

: print  ( array numToPrint -- )
	0 do
		dup
		i + ( add i to the address of the string )
		c@ emit ( dereference stack and emit character )
	loop
	pop
;

: fizzbuzz
	0 do
		i 0 = if
			0 .
		else
			i 15 % 0 = if
				s" fizzbuzz" print cr
			else
				i 3 % 0 = if
					s" fizz" print cr
				else
					i 5 % 0 = if
						s" buzz" print cr
					else
						i .
					then
				then
			then
		then
	loop
;

: ,
	swap show
	dup show
	rot show
	rot show
	! show
	1 show cells show + show
;

array test

: cells cell * ;
variable array 5 cell allot

: array-test
	4 0 do
		420 i + array i cells + !
	loop
	4 0 do
		array cell i * + @ .
	loop
;

emit test

: jim 74 emit 105 emit 109 emit 10 emit ;



: test
	2 0 do
		i 1 = if
			3 0 do
				i .
			loop
		else
			s" jim" print
		then
	loop
;
: test
	10 0 do
	i 1 = if
		s" One" print cr
	else i 2 = if
		s" Two" print cr
	else i 3 = if
		s" Three" print cr
	else
		i .
	then then then
	  loop
;

*/


/* Typedefs ************************************************************************************** */

typedef int32_t Cell;

/* Defines ************************************************************************************** */

#define Kb (1024)
#define INT_STACK_SIZE 128
#define COMPILED_WORDS_SIZE (1024 * Kb)
#define MAX_WORD_NAME_LEN (64)
#define MAX_NUM_COMPILED_WORDS (1000)
#define CONTROL_FLOW_STACK_SIZE 128
#define LOOP_STACK_SIZE 128
#define MAX_NUM_VARIABLES 256
#define STRING_LITERAL_BUFFER_SIZE Kb

#define NEXT_TOKEN_IS_LITERAL_WORD 0

// replace 4 with the a define for cell size
#define MAX_OUPUTTED_TOKENS_FROM_COMPILE ( STRING_LITERAL_BUFFER_SIZE / 4)

#define BYTECODE_ALIGNMENT 4

#define COMPILE_BYTECODE 

#define SIZEOF_CELL sizeof(Cell)

#define RETURN_STACK_SIZE 128


/* Typedefs ************************************************************************************** */

typedef enum {
	IntCell,
	// FloatCell
}AllotType;

typedef enum {
	FInt,
	FIntArray,
	FString
}VariableType;

typedef enum {
	false,
	true
}bool;

typedef enum {
	NoFlagsSet = 1,
	Immediate = 2,
	CommentFlagSet = 4,
	CurrentNestIsNotReadable = 8,
	ParsingStringLiteralFlag = 16

}WordAvailability;

typedef enum {
	CompiledWordAddSuccess,
	CompiledWordAddFailure
}AddToCompiledWordResult;

typedef enum {
	Pass,
	FailStackEmpty,
	FailStackFull
}StackChangeResult;

typedef enum {
	IfRuntimeError,
	Force, // used for words that set the read position of the token stream - such as loop - these will return ExecutionPositionChangedByWord
	IfChangedExecutionPosition
}ReturnValueFromProcessTokenPolicy;

typedef ForthDoStringResult(*CFunctionPtrWord)(char** token);

typedef struct {
	Cell* bytecode;
	size_t namelen;
	char name[MAX_WORD_NAME_LEN];
	bool isCFunction;
	CFunctionPtrWord cFunctionPtr;
	size_t numTokens;
	WordAvailability availability;
	ReturnValueFromProcessTokenPolicy returnValuePolicy;
}CompiledWordInfo;

typedef struct {
	size_t tokenNumber;
	char* tokenToStartLoop;
	Cell i;
	Cell limit;
}LoopInfo;

typedef struct {
	char name[MAX_WORD_NAME_LEN];
	VariableType type;
	size_t sizeCells;
	void* address;
}VariableInfo;

/* Macros ************************************************************************************** */

// define a stack with the variables name (the array itself), nameTop (points to top of stack), nameSize (size of stack)
// also defines functions to pop push and peek the stack, named by concatenating Push, Peek, and Pop to the start of the name to name the functions
#define STACK(name, size, type) static type name[size]; static type* name##Top; static size_t name##Size;\
	static type* Peek##name() { return (name##Top - 1); }\
	static StackChangeResult Push##name(type val){\
		if (name##Size >= size) {\
			return FailStackFull;\
		}\
		*(name##Top++) = val;\
		name##Size++;\
		return Pass;\
	}\
	static StackChangeResult Pop##name(type* val) {\
		if (name##Top == name) {\
			return FailStackEmpty;\
		}\
		*val = *(--name##Top);\
		name##Size--;\
		return Pass;\
	}

/* Static variables ************************************************************************************** */

static CompiledWordInfo _compiledWordsInfos[MAX_NUM_COMPILED_WORDS];
static int _numCompiledWords = 0;

static bool _commentFlag = false;
static bool _compileFlag = false;
static bool _settingVariableFlag = false;
static bool _parsingStringLiteralFlag = false;

STACK(_intStack, INT_STACK_SIZE, Cell);
STACK(_returnStack, RETURN_STACK_SIZE, size_t);

static VariableInfo _variables[MAX_NUM_VARIABLES];
static VariableInfo* _variablesTop;
static size_t _numVariables = 0;

static char _stringLiteralBuffer[STRING_LITERAL_BUFFER_SIZE];
static char* _stringLiteralBufferEnd;

static AllocateHeap _alloc;
static FreeHeap _free;
static ReallocateHeap _reallocate;
static ForthPrintf _printf;
static ForthPutChar _putchar;

static size_t _ip = 0; // instruction pointer
static char* _stringIp; // for interpreter mode

static Cell _compiledWordsBytecode[COMPILED_WORDS_SIZE];
static Cell* _compileWordsBytecodeNext;

static bool _nextByteCodeValueIsLiteral = false;

static bool _nextTokenIsStringLiteral = false;



// useful words
char* _startupCode =
// converts a number of cells to that number of bytes
": if "
"here show " // push here
"compile branch0 "  //compile branch0
"0 , "              //compile 0 branch offset place holder, to be back-filled by then or else
//"2 "                //push 2 onto stack to signify that the address pushed is the start of an if
"; immediate "


": cells ( offset -- convertedToNumberOfCells ) cell * ; "

": here dp @ ; immediate "

": allot here + dp ! ; immediate "


": then " // ( ifAddress )
"dup " // ( ifAddress ifAddress )
"here " // ( ifAddress ifAddress thenAddress )
"- " // ( ifAddress branchOffset)
"swap 1 cells + " //( branchOffset ifAddress+1cell)
"! "
"; immediate "

": , compile here ! 1 allot ; "
": c, compile here c! 1 allot ; "

;

/* Forward Declarations ************************************************************************************** */

ForthDoStringResult PrintIntStack();

/* Static functions ************************************************************************************** */

#pragma region variables helpers

static ForthDoStringResult PushVariableAddressOntoStack(int variableIndex) {
	if (variableIndex >= _numVariables || variableIndex < 0) return RuntimeError;
	Push_intStack((int)_variables[variableIndex].address);
}

static void AddIntVariable(const char* name, void* address) {
	int namesize = strlen(name);
	if (namesize >= MAX_WORD_NAME_LEN) {
		_printf("Name too long - soz!");
	}
	for (int i = 0; i < _numVariables; i++) {
		if (strcmp(_variables[i].name, name) == 0) {
			return; // don't allocate a new one if there's already one by this name
		}
	}
	VariableInfo vi;
	strcpy_s(vi.name, namesize + 1, name);
	vi.type = FInt;
	vi.address = address;
	vi.sizeCells = 1;
	*(_variablesTop++) = vi;
	_numVariables++;
}

#pragma endregion

#pragma region integer stack helpers

static ForthDoStringResult Pop1IntHelper(Cell* int1) {
	size_t* _ = NULL;
	char** __ = NULL;

	if (Pop_intStack(int1) == FailStackEmpty) {
		_printf("Pop1IntHelper, stack empty\n");
		PrintIntStack(_, __);
		return RuntimeError;
	}
	return HelperDoneOkay;
}

static ForthDoStringResult Pop2IntsHelper(Cell* int1, Cell* int2) {
	size_t* _ = NULL;
	char** __ = NULL;
	if (Pop_intStack(int1) == FailStackEmpty) {
		_printf("Pop2IntHelper failed, stack empty\n");
		PrintIntStack(_, __);
		return RuntimeError;
	}
	if (Pop_intStack(int2) == FailStackEmpty) {
		_printf("Pop2IntHelper failed, stack empty\n");
		PrintIntStack(_, __);
		return RuntimeError;
	}
	return HelperDoneOkay;
}

static ForthDoStringResult Pop3IntsHelper(Cell* int1, Cell* int2, Cell* int3) {
	size_t* _ = NULL;
	char** __ = NULL;

	if (Pop_intStack(int1) == FailStackEmpty) {
		_printf("Pop3IntHelper failed, stack empty\n");
		PrintIntStack(_, __);
		return RuntimeError;
	}
	if (Pop_intStack(int2) == FailStackEmpty) {
		_printf("Pop3IntHelper failed, stack empty\n");
		PrintIntStack(_, __);
		return RuntimeError;
	}
	if (Pop_intStack(int3) == FailStackEmpty) {
		_printf("Pop3IntHelper failed, stack empty\n");
		PrintIntStack(_, __);
		return RuntimeError;
	}
	return HelperDoneOkay;
}

#pragma endregion

#pragma region Built in forth words

static ForthDoStringResult HereWord(char** __) {
	Push_intStack(_compileWordsBytecodeNext);
}

static ForthDoStringResult AllotWord(char** __) {
	Cell int1;
	if (Pop1IntHelper(&int1) != Pass) return RuntimeError;
	_compileWordsBytecodeNext += int1;
}

static ForthDoStringResult ImmediateWord(char** __) {
	_compiledWordsInfos[_numCompiledWords - 1].availability |= Immediate;
}

static ForthDoStringResult Branch0(char** __) {
	Cell val;
	if (Pop_intStack(&val) != Pass) return RuntimeError;
	if (val == 0) {
		_ip += _compiledWordsBytecode[_ip + 1];
	}
	else {
		_ip++;
	}
}

static ForthDoStringResult Branch(char** __) {
	_ip += _compiledWordsBytecode[_ip + 1];
}


static ForthDoStringResult PrintIntStack(char** __) {
	_printf("[ ");
	for (Cell* ptr = _intStack; ptr < _intStackTop; ptr++) {
		_printf("%i", *ptr);
		if (ptr < _intStackTop - 1) {
			_printf(", ");
		}
	}
	_printf(" ]\n");
	return TokenDoneOkay;
}

static ForthDoStringResult Modulo(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack(int2 % int1) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult Add(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack(int1 + int2) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult Subtract(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack(int2 - int1) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult Multiply(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack(int1 * int2) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult Divide(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack(int2 / int1) != Pass) return RuntimeError;
	return TokenDoneOkay;

}

static ForthDoStringResult Equal(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack((int1 == int2) ? -1 : 0) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult NotEqual(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack((int1 != int2) ? -1 : 0) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult And(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack(((int1 == -1) && (int2 == -1)) ? -1 : 0) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult Or(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack(((int1 == -1) || (int2 == -1)) ? -1 : 0) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult GreaterThan(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack((int2 > int1) ? -1 : 0) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult LessThan(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack((int2 < int1) ? -1 : 0) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult GreaterThanOrEqual(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack((int2 >= int1) ? -1 : 0) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult LessThanOrEqual(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	if (Push_intStack((int2 <= int1) ? -1 : 0) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult Dup(char** __) {
	if (_intStackTop == _intStack) {
		_printf("empty stack dumbass\n");
		return RuntimeError;
	}
	if (Push_intStack(*(_intStackTop - 1)) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult Rot(char** __) {
	Cell int1, int2, int3;
	Pop3IntsHelper(&int1, &int2, &int3);
	Push_intStack(int2);
	Push_intStack(int1);
	Push_intStack(int3);
	return TokenDoneOkay;
}

static ForthDoStringResult TwoDup(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	Push_intStack(int2);
	Push_intStack(int1);
	Push_intStack(int2);
	Push_intStack(int1);
	return TokenDoneOkay;
}

static ForthDoStringResult Swap(char** __) {
	if (_intStackTop - 2 < _intStack) return RuntimeError;
	Cell* int1;
	Cell* int2;
	int1 = _intStackTop - 1;
	int2 = _intStackTop - 2;
	Cell int1Copy = *int1;
	*int1 = *int2;
	*int2 = int1Copy;
	return TokenDoneOkay;

}

static ForthDoStringResult PopWord(char** __) {
	Cell ___;
	if (Pop_intStack(&___) != Pass) return RuntimeError;
	return TokenDoneOkay;

}

void DebugPrintWordContents(const char* contents, int numTokens) {
	const char* token = contents;
	for (int i = 0; i < numTokens; i++) {
		_printf(token);
		_printf(" ");
		token += strlen(token) + 1;
	}
	_printf("\n");
	return TokenDoneOkay;
}

static ForthDoStringResult DebugPrintCompiledWords(char** __) {
	for (int i = 0; i < _numCompiledWords; i++) {
		_printf("%i name: %s", i, _compiledWordsInfos[i].name);
		//DebugPrintWordContents(_compiledWordsInfos[i].contents, _compiledWordsInfos[i].numTokens);
		_printf(" num tokens: %i", _compiledWordsInfos[i].numTokens);
	}
	_printf("\n");
	return TokenDoneOkay;
}

static ForthDoStringResult Assign(char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	*((Cell*)int1) = int2;
	return TokenDoneOkay;
}

static ForthDoStringResult Dereference(char** __) {
	Cell int1 = 0;
	if (Pop1IntHelper(&int1) != HelperDoneOkay) return RuntimeError;
	Push_intStack(*((Cell*)int1));
	return TokenDoneOkay;
}

static ForthDoStringResult AssignChar() {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	*((char*)int1) = (char)int2;
	return TokenDoneOkay;
}

static ForthDoStringResult DereferenceChar(char** __) {
	Cell int1 = 0;
	if (Pop1IntHelper(&int1) != HelperDoneOkay) return RuntimeError;
	Push_intStack(*((char*)int1));
	return TokenDoneOkay;
}

static ForthDoStringResult Dot(char** __) {
	Cell int1 = 0;
	if (Pop1IntHelper(&int1) != HelperDoneOkay) return RuntimeError;
	_printf("%i\n", int1);
	return TokenDoneOkay;

}

static ForthDoStringResult StartCompile(char** __) {
	_compileFlag = 1;
	_compiledWordsInfos[_numCompiledWords].bytecode = _compileWordsBytecodeNext;
	_compiledWordsInfos[_numCompiledWords].numTokens = 0;
	_compiledWordsInfos[_numCompiledWords].numTokens = false;
	return TokenDoneOkay;
}

static ForthDoStringResult EndCompile(char** token) {
	_compileFlag = 0;
	_compiledWordsInfos[_numCompiledWords].isCFunction = false;
	_compiledWordsInfos[_numCompiledWords].cFunctionPtr = NULL;
	_compiledWordsInfos[_numCompiledWords].availability = NoFlagsSet;
	_numCompiledWords++;
	return TokenDoneOkay;

}

static ForthDoStringResult StartCommentWord(char** __) {
	if (_commentFlag) return CompileError;
	_commentFlag = true;
	return TokenDoneOkay;
}

static ForthDoStringResult EndCommentWord(char** __) {
	if (!_commentFlag) return CompileError;
	_commentFlag = false;
	return TokenDoneOkay;
}

static ForthDoStringResult SetVariableFlagWord(char** __) {
	if (_settingVariableFlag) return RuntimeError;
	_settingVariableFlag = true;
	return TokenDoneOkay;
}

static ForthDoStringResult CellsWord(char** __) {
	if (Push_intStack(SIZEOF_CELL) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

//static ForthDoStringResult AllotWord(char** __) {
//	Cell cellSizeInBytes, sizeInCells;
//	if (Pop2IntsHelper(&cellSizeInBytes, &sizeInCells) != HelperDoneOkay) return RuntimeError;
//	VariableInfo* lastVar = _variablesTop - 1;
//	sizeInCells++;
//	if (lastVar->sizeCells != sizeInCells) {
//		lastVar->sizeCells = sizeInCells;
//		_reallocate(lastVar->address, sizeInCells * cellSizeInBytes);
//	}
//	return TokenDoneOkay;
//}

static ForthDoStringResult EmitWord(char** token) {
	Cell int1;
	if (Pop1IntHelper(&int1) != HelperDoneOkay) return RuntimeError;
	_putchar(int1);
	//_printf("%c", (char)int1);
	return TokenDoneOkay;
}

static ForthDoStringResult NextTokenIsLiteralWord(char** token) {
	_nextByteCodeValueIsLiteral = true;
	return TokenDoneOkay;
}

static ForthDoStringResult CompileWord(char** token) {
	*(_compileWordsBytecodeNext++) = _compiledWordsBytecode[_ip + 1];
	_ip++;
	return TokenDoneOkay;
}

#pragma endregion

#pragma region core interpreter

static void CompileTokenToBytecode(char* token, Cell* output, int* numTokensOutputted) {
	/*
		compiles text token into bytecode - one text token may emit several bytecode tokens

		> words compile to their index

		> variable names compile to (0, variable address) ie look up variable address at compile time and push its address as a literal

		> currently can't use the variable word in compile mode - to implement this I'll probably have to store the variable name in the same way as string literals

		> "3"  would compile to 0, 3 (in this program the word 0 signifies the next token is a number literal)

		> Inlined strings are compiled into the bytecode for the word like this :

																																   <-----------------------(n cells)-------------------------------->
		|CELL0 (or another token signifying a string literal follows)  |CELL1 (signifies number of cells containing string bytes) |CELL2               | CELL3           |  CELL4          |         |
		|    value 2                                                   | length of string, n cells                                | data for string    | data for string | data for string | ect...  |

		> the cells themselves are aligned according to BYTECODE_ALIGNMENT

	*/
	* numTokensOutputted = 0;
	if (_nextTokenIsStringLiteral) {
		Cell stringSizeBytes = strlen(token);
		Cell cellsRequired = stringSizeBytes % BYTECODE_ALIGNMENT ? (stringSizeBytes / SIZEOF_CELL) + 1 : stringSizeBytes / SIZEOF_CELL;
		*numTokensOutputted = cellsRequired + 1; // +1 for the next cell which tells how many the string takes up
		output[0] = cellsRequired;
		for (int i = 1; i < cellsRequired + 1; i++) {
			output[i] = *((Cell*)token);
			token += SIZEOF_CELL;
		}
		return;
	}
	for (int i = 0; i < _numCompiledWords; i++) {
		if (strcmp(_compiledWordsInfos[i].name, token) == 0) {
			*numTokensOutputted = 1;
			*output = (Cell)i;
			return;
		}
	}
	int parsed = atoi(token);
	if (strcmp(token, "0") == 0 || parsed > 0) {
		*numTokensOutputted = 2;
		output[0] = NEXT_TOKEN_IS_LITERAL_WORD;
		output[1] = (Cell)parsed;
		return;
	}
	for (int i = 0; i < _numVariables; i++) {
		if (strcmp(_variables[i].name, token) == 0) {
			*numTokensOutputted = 2;
			output[0] = NEXT_TOKEN_IS_LITERAL_WORD;
			output[1] = _variables[i].address;
			return;
		}
	}

}

static ForthDoStringResult CompileToByteCode(const char* token) {

	Cell outputtedTokens[MAX_OUPUTTED_TOKENS_FROM_COMPILE];
	int numTokensOutputted = 0;
	if (_compiledWordsInfos[_numCompiledWords].namelen == 0) {
		//AddNullCharacterToCompiledWordsData();
		if (atoi(token) != 0) {
			_printf("You can't name a word with a number in this forth\n");
			return CompileError;
		}
		_compiledWordsInfos[_numCompiledWords].namelen = strlen(token);
		memcpy(_compiledWordsInfos[_numCompiledWords].name, token, _compiledWordsInfos[_numCompiledWords].namelen);
		_compiledWordsInfos[_numCompiledWords].name[_compiledWordsInfos[_numCompiledWords].namelen] = '\0';
	}
	else {
		CompileTokenToBytecode(token, outputtedTokens, &numTokensOutputted);
		_compiledWordsInfos[_numCompiledWords].numTokens += numTokensOutputted;
		for (int i = 0; i < numTokensOutputted; i++) {
			*(_compileWordsBytecodeNext++) = outputtedTokens[i];
		}
	}
}

ForthDoStringResult StartParsingString() {
	if (_parsingStringLiteralFlag) {
		_printf("probably an unclosed .\"\n");
		return CompileError;
	}
	_parsingStringLiteralFlag = true;
	return TokenDoneOkay;
}

void StopParsingString(const char* token) {
	char* t = token;
	*(_stringLiteralBufferEnd++) = '\0';
	if (!_compileFlag) {
		//_printf("%s\n", _stringLiteralBuffer); // need to sort out compile time behavior of words better
		if (Push_intStack(_stringLiteralBuffer) != Pass) return RuntimeError;
		if (Push_intStack(strlen(_stringLiteralBuffer)) != Pass) return RuntimeError;

	}
	_stringLiteralBufferEnd = _stringLiteralBuffer;
	_parsingStringLiteralFlag = false;
}

static ForthDoStringResult AddToStringLiteralBuffer(const char* token) {
	for (int i = 0; i < STRING_LITERAL_BUFFER_SIZE; i++) {
		if (token[i] == '\"') {
			StopParsingString(token);
			return TokenDoneOkay;
		}
		*(_stringLiteralBufferEnd++) = token[i];
	}
	_printf("string too long or you forgot to end it \n");
	return CompileError;
}

static ForthDoStringResult RunWord(int wordIndex) {
#ifdef COMPILE_BYTECODE
	size_t offset = _compiledWordsInfos[wordIndex].bytecode - _compiledWordsBytecode;
	ForthDoStringResult res = DoBytecodeWord(offset, _compiledWordsInfos[wordIndex].numTokens);
#else
	ForthDoStringResult res = DoPreTokenizedString(_compiledWordsInfos[wordIndex].contents,
		_compiledWordsInfos[wordIndex].numTokens);
#endif
	return res;
}

static bool FindAndRunWordHelper(const char** token, ForthDoStringResult* possibleReturnVal, WordAvailability availability) {
	ReturnValueFromProcessTokenPolicy policy;
	*possibleReturnVal = FindAndRunWord(token, availability, &policy);
	switch (policy)
	{
	case IfRuntimeError:
		if (*possibleReturnVal == RuntimeError) {
			return true;
		}
		break;
	case Force:
		return true;
		break;
	case IfChangedExecutionPosition:
		if (*possibleReturnVal == ExecutionPositionChangedByWord) {
			return true;
		}
	default:
		break;
	}
	return false;
}

static ForthDoStringResult ProcessToken(const char** token) {
	ForthDoStringResult rVal = TokenDoneOkay;
	_nextTokenIsStringLiteral = _parsingStringLiteralFlag;
	if (_parsingStringLiteralFlag) {

		AddToStringLiteralBuffer(*token);
		//return TokenDoneOkay;
	}

	if (_commentFlag && _compileFlag) {
		if (FindAndRunWordHelper(token, &rVal, CommentFlagSet)) {
			return rVal;
		}
	}
	else if (_compileFlag) {
		if (FindAndRunWordHelper(token, &rVal, Immediate)) {
			return rVal;
		}
		else if (rVal == WordNotFound || (strcmp(*token, "s\"") == 0)) {
			CompileToByteCode(*token);
		}
	}
	else {
		int converted = atoi(*token);
		if (strcmp(*token, "0") == 0) {
			if (_settingVariableFlag) {
				_printf("variable flag must be followed by a name");
				return RuntimeError;
			}
			// atoi returns 0 when it can't be converted... so I suppose we need this special case
			Push_intStack(0);
		}
		else if (converted) {
			if (_settingVariableFlag) {
				_printf("variable flag must be followed by a name");
				return RuntimeError;
			}
			// this token is an integer
			Push_intStack(converted);
		}
		else if (converted == 0) {
			if (_settingVariableFlag) {
				_settingVariableFlag = false;
				AddIntVariable(*token, _alloc(SIZEOF_CELL));
			}
			else {
				if (FindAndRunWordHelper(token, &rVal, NoFlagsSet)) {
					return rVal;
				}
			}
		}
	}
	return TokenDoneOkay;
}

ForthDoStringResult FindAndRunWord(char** token, WordAvailability flags, ReturnValueFromProcessTokenPolicy* policyOut) {
	for (int i = _numCompiledWords - 1; i >= 0; i--) {
		CompiledWordInfo* info = _compiledWordsInfos + i;
		*policyOut = info->returnValuePolicy;
		if ((info->availability & flags) == 0) {
			continue;
		}
		if (strcmp(*token, info->name) == 0) {
			if (info->isCFunction) {
				return info->cFunctionPtr(token);
			}
			else {
				return RunWord(i);
			}
		}
	}
	for (int i = 0; i < _numVariables; i++) {
		if (strcmp(*token, _variables[i].name) == 0) {
			if (PushVariableAddressOntoStack(i) == RuntimeError) return RuntimeError;
			else return WordNotFound;
		}
	}
	//printf("Word not found\n");
	return WordNotFound;
}

ForthDoStringResult DoPreTokenizedString(const char* string, int numTokens) {
	char* token = string;
	for (_ip = 0; _ip < numTokens; _ip++) {

		ForthDoStringResult res = ProcessToken(&token);
		if (res != TokenDoneOkay && res != ExecutionPositionChangedByWord) {
			return res;
		}
		if (res != ExecutionPositionChangedByWord) {
			token += strlen(token) + 1;
			while (*token == '\0') token++;
		}
	}
	return StringDoneOkay;
}

static ForthDoStringResult InterpretBytecodeToken(Cell token, WordAvailability flags) {
	char** _ = NULL;

	if (token >= _numCompiledWords || token < 0) {
		_printf("word: %i not found\n", token);
		return RuntimeError;
	}
	if ((_compiledWordsInfos[token].availability & flags) == 0) {
		return TokenDoneOkay; // token has been ignored as it's availability doesn't match current availability - this is Ok
	}
	if (_compiledWordsInfos[token].isCFunction) {
		return _compiledWordsInfos[token].cFunctionPtr(_);
	}
	else {
		size_t offset = _compiledWordsInfos[token].bytecode - _compiledWordsBytecode;
		return DoBytecodeWord(offset, _compiledWordsInfos[token].numTokens);
	}

}

static ForthDoStringResult ProcessBytecodeToken(Cell token, size_t* tokenNumber) {
	ForthDoStringResult rVal = TokenDoneOkay;


	if (_nextByteCodeValueIsLiteral) {
		if (_settingVariableFlag) {
			_printf("variable flag must be followed by a name");
			return RuntimeError;
		}
		Push_intStack(token);
		_nextByteCodeValueIsLiteral = false;
	}
	else {
		if (_settingVariableFlag) {
			_settingVariableFlag = false;
			//AddIntVariable(*token);
		}
		else {
			InterpretBytecodeToken(token, NoFlagsSet);
		}
	}
	return TokenDoneOkay;
}

static ForthDoStringResult DoBytecodeWord(size_t newIpVal, int numTokens) {
	if (Push_returnStack(_ip) != Pass) return RuntimeError;

	for (_ip = newIpVal; _ip < newIpVal + numTokens; _ip++) {
		Cell val = _compiledWordsBytecode[_ip];

		if (_parsingStringLiteralFlag) {
			// parse string literal and skip over the string data to the token on the other side
			int stringSizeCells = _compiledWordsBytecode[_ip++];
			const char* string = (const char*)&_compiledWordsBytecode[_ip];
			AddToStringLiteralBuffer(string);
			_ip += stringSizeCells - 1;
		}
		else if ((_compiledWordsBytecode[_ip - 1] == 1) && (_compiledWordsBytecode[_ip - 2] != 0)) { // BUG!! Fixed?
			// we're not parsing a string literal but we need to skip over the string data
			int stringSizeCells = _compiledWordsBytecode[_ip++];
			_ip += stringSizeCells - 1;
		}
		else {
			ProcessBytecodeToken(_compiledWordsBytecode[_ip], &_ip);
		}
	}
	if (Pop_returnStack(&_ip) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

#pragma endregion

#pragma region misc helpers

char* SkipStringLiteral(char* nextToken) {

	for (int i = 0; i < STRING_LITERAL_BUFFER_SIZE; i++) {
		if (nextToken[i] == '\"') {
			return nextToken + i;
		}
	}
	return NULL;
}

void AddCFunctionWord(const char* name, CFunctionPtrWord cFunctionPtr, WordAvailability availability, ReturnValueFromProcessTokenPolicy policy) {
	CompiledWordInfo info;
	int baseLength = strlen(name);
	strcpy_s(info.name, baseLength + 1, name);
	info.namelen = baseLength;
	info.isCFunction = true;
	info.cFunctionPtr = cFunctionPtr;
	info.numTokens = 0;
	info.returnValuePolicy = policy;
	info.availability = availability;
	_compiledWordsInfos[_numCompiledWords++] = info;
}

#pragma endregion

/* Public functions ************************************************************************************** */

void Forth_Initialise(AllocateHeap allocator, FreeHeap freeAllocated, ReallocateHeap reallocate, ForthPrintf fPrintf, ForthPutChar fPutchar)
{
	_intStackTop = _intStack;
	memset(_compiledWordsInfos, 0, sizeof(CompiledWordInfo) * MAX_NUM_COMPILED_WORDS);

	_variablesTop = _variables;
	memset(_variables, 0, sizeof(VariableInfo) * MAX_NUM_VARIABLES);

	_stringLiteralBufferEnd = _stringLiteralBuffer;
	memset(_stringLiteralBuffer, 0, STRING_LITERAL_BUFFER_SIZE);

	_returnStackTop = _returnStack;
	memset(_returnStack, 0, RETURN_STACK_SIZE);

	_compileWordsBytecodeNext = _compiledWordsBytecode;

	AddIntVariable("dp", &_compileWordsBytecodeNext);

	AddCFunctionWord("literal", &NextTokenIsLiteralWord, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord("s\"", &StartParsingString, NoFlagsSet | Immediate, IfRuntimeError);
	AddCFunctionWord(".", &Dot, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord("show", &PrintIntStack, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("+", &Add, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("-", &Subtract, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("/", &Divide, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("*", &Multiply, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("%", &Modulo, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("pop", &PopWord, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("dup", &Dup, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("twodup", &TwoDup, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("=", &Equal, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("!=", &NotEqual, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("and", &And, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("or", &Or, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord(">", &GreaterThan, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord(">=", &GreaterThanOrEqual, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("<", &LessThan, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("<=", &LessThanOrEqual, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("rot", &Rot, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("swap", &Swap, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord("branch0", &Branch0, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("branch", &Branch, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("immediate", &ImmediateWord, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord("c@", &DereferenceChar, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("c!", &AssignChar, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("!", &Assign, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("@", &Dereference, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord(":", &StartCompile, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord(";", &EndCompile, Immediate, IfRuntimeError);

	AddCFunctionWord("(", &StartCommentWord, Immediate, IfRuntimeError);
	AddCFunctionWord(")", &EndCommentWord, CommentFlagSet, IfRuntimeError);

	AddCFunctionWord("variable", &SetVariableFlagWord, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("compiler", &DebugPrintCompiledWords, NoFlagsSet | Immediate, IfRuntimeError);

	AddCFunctionWord("cell", &CellsWord, NoFlagsSet, IfRuntimeError);
	//AddCFunctionWord("allot", &AllotWord, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord("emit", &EmitWord, NoFlagsSet, IfRuntimeError);

	//AddCFunctionWord("here", &HereWord, Immediate, IfRuntimeError);

	AddCFunctionWord("compile", &CompileWord, Immediate, IfRuntimeError);

	_alloc = allocator;
	_free = freeAllocated;
	_reallocate = reallocate;
	_printf = fPrintf;
	_putchar = fPutchar;
	int tokens = 0;

	// can't just give Forth_DoString a string literal because it alters the string
	char* startupCodeBuf = _alloc(strlen(_startupCode) + 1);
	strcpy_s(startupCodeBuf, strlen(_startupCode) + 1, _startupCode);
	Forth_DoString(startupCodeBuf, &tokens);
	_free(startupCodeBuf);

	
}

ForthDoStringResult Forth_DoString(const char* inputString, int* numTokens)
{
	char* delim = " \t\n";
	char* nextToken;
	const char* token = strtok_s(inputString, delim, &nextToken);
	const char* firstToken = token;
	while (token != NULL) {
		(*numTokens)++;
		if (strcmp(token, "s\"") == 0) {
			char* newNext = SkipStringLiteral(nextToken); // skip the nextToken
			if (newNext == NULL) {
				_printf("you probably forgot the closing \" or you gave a string that was too long to .\"\n");
				return CompileError;
			}
			nextToken = newNext;
		}

		token = strtok_s(NULL, delim, &nextToken);
	}
	// strtok_s modifies the underlying string, so strtok_s the  entire string and work with the result. 
	// All the above really does is replace '\t', '\n' and ' ' with '\0', skipping string literals
	// which are signified by the token following this token: "s\"" -> looks like s" 
	return DoPreTokenizedString(firstToken, *numTokens);
}

void Forth_Teardown()
{
	for (int i = 0; i < _numVariables; i++) {
		_free(_variables[i].address);
	}
}