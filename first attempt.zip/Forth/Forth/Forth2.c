//#include "Forth.h"
//#include <stdio.h>
//#include <string.h>
//#include <stdint.h>
//
///*
//
//bytecode version WIP
//
//Forth interpreter - � Jim Marshall 2022
//
//Loosly based on this youtubers videos on writing a forth interpreter: Thanks!
//https://www.youtube.com/@JoeKreydt
//
//Example forth code for doing fibonacci sequence
//
//: fib
//	twodup
//	+
//;
//
//: fibLoop
//	0 do
//		fib
//		rot
//		pop
//		dup
//		.
//	loop
//;
//
//: computeFib
//	0 1
//	rot ( rotate to get the users number on the top of the stack for the do loop )
//	fibLoop
//;
//
//fizz buzz
//
//: cr 10 emit ;
//
//: print  ( array numToPrint -- )
//	0 do
//		dup
//		i + ( add i to the address of the string )
//		c@ emit ( dereference stack and emit character )
//	loop
//	pop
//;
//
//: fizzbuzz
//	0 do
//		i 0 = if
//			0 .
//		else
//			i 15 % 0 = if
//				s" fizzbuzz" print cr
//			else
//				i 3 % 0 = if
//					s" fizz" print cr
//				else
//					i 5 % 0 = if
//						s" buzz" print cr
//					else
//						i .
//					then
//				then
//			then
//		then
//	loop
//;
//
//: ,
//	swap show
//	dup show
//	rot show
//	rot show
//	! show
//	1 show cells show + show
//;
//
//array test
//
//: cells cell * ;
//variable array 5 cell allot
//
//: array-test
//	4 0 do
//		420 i + array i cells + !
//	loop
//	4 0 do
//		array cell i * + @ .
//	loop
//;
//
//emit test
//
//: jim 74 emit 105 emit 109 emit 10 emit ;
//
//
//
//: test
//	2 0 do
//		i 1 = if
//			3 0 do
//				i .
//			loop
//		else
//			s" jim" print
//		then
//	loop
//;
//: test
//	10 0 do
//	i 1 = if
//		s" One" print cr
//	else i 2 = if
//		s" Two" print cr
//	else i 3 = if
//		s" Three" print cr
//	else
//		i .
//	then then then
//	  loop
//;
//
//*/
//
//
///* Typedefs ************************************************************************************** */
//
//typedef int32_t Cell;
//
///* Defines ************************************************************************************** */
//
//#define Kb (1024)
//#define INT_STACK_SIZE 128
//#define COMPILED_WORDS_SIZE (1024 * Kb)
//#define MAX_WORD_NAME_LEN (64)
//#define MAX_NUM_COMPILED_WORDS (1000)
//#define CONTROL_FLOW_STACK_SIZE 128
//#define LOOP_STACK_SIZE 128
//#define MAX_NUM_VARIABLES 256
//#define STRING_LITERAL_BUFFER_SIZE Kb
//
//#define NEXT_TOKEN_IS_LITERAL_WORD 0
//
//// replace 4 with the a define for cell size
//#define MAX_OUPUTTED_TOKENS_FROM_COMPILE ( STRING_LITERAL_BUFFER_SIZE / 4)
//
//#define BYTECODE_ALIGNMENT 4
//
//#define COMPILE_BYTECODE 
//
//#define SIZEOF_CELL sizeof(Cell)
//
//#define RETURN_STACK_SIZE 128
//
//
///* Typedefs ************************************************************************************** */
//
//typedef enum {
//	IntCell,
//	// FloatCell
//}AllotType;
//
//typedef enum {
//	FInt,
//	FIntArray,
//	FString
//}VariableType;
//
//typedef enum {
//	false,
//	true
//}bool;
//
//typedef enum {
//	NoFlagsSet = 1,
//	Immediate = 2,
//	CommentFlagSet = 4,
//}WordAvailability;
//
//typedef enum {
//	CompiledWordAddSuccess,
//	CompiledWordAddFailure
//}AddToCompiledWordResult;
//
//typedef enum {
//	Pass,
//	FailStackEmpty,
//	FailStackFull
//}StackChangeResult;
//
//typedef enum {
//	IfRuntimeError,
//	Force, // used for words that set the read position of the token stream - such as loop - these will return ExecutionPositionChangedByWord
//	IfChangedExecutionPosition
//}ReturnValueFromProcessTokenPolicy;
//
//typedef ForthDoStringResult(*CFunctionPtrWord)(char** token);
//
//typedef struct {
//	Cell* bytecode;
//	size_t namelen;
//	char name[MAX_WORD_NAME_LEN];
//	bool isCFunction;
//	CFunctionPtrWord cFunctionPtr;
//	size_t numTokens;
//	WordAvailability availability;
//	ReturnValueFromProcessTokenPolicy returnValuePolicy;
//}CompiledWordInfo;
//
//typedef struct {
//	size_t tokenNumber;
//	char* tokenToStartLoop;
//	Cell i;
//	Cell limit;
//}LoopInfo;
//
//typedef struct {
//	char name[MAX_WORD_NAME_LEN];
//	VariableType type;
//	size_t sizeCells;
//	void* address;
//}VariableInfo;
//
///* Macros ************************************************************************************** */
//
//// define a stack with the variables name (the array itself), nameTop (points to top of stack), nameSize (size of stack)
//// also defines functions to pop push and peek the stack, named by concatenating Push, Peek, and Pop to the start of the name to name the functions
//#define STACK(name, size, type) static type name[size]; static type* name##Top; static size_t name##Size;\
//	static type* Peek##name() { return (name##Top - 1); }\
//	static StackChangeResult Push##name(type val){\
//		if (name##Size >= size) {\
//			return FailStackFull;\
//		}\
//		*(name##Top++) = val;\
//		name##Size++;\
//		return Pass;\
//	}\
//	static StackChangeResult Pop##name(type* val) {\
//		if (name##Top == name) {\
//			return FailStackEmpty;\
//		}\
//		*val = *(--name##Top);\
//		name##Size--;\
//		return Pass;\
//	}
//
///* Static variables ************************************************************************************** */
//
//static CompiledWordInfo _compiledWordsInfos[MAX_NUM_COMPILED_WORDS];
//static int _numCompiledWords = 0;
//
//static bool _commentFlag = false;
//static bool _compileFlag = false;
//static bool _settingVariableFlag = false;
//static bool _parsingStringLiteralFlag = false;
//
//STACK(_intStack, INT_STACK_SIZE, Cell);
//STACK(_returnStack, RETURN_STACK_SIZE, size_t);
//
//static VariableInfo _variables[MAX_NUM_VARIABLES];
//static VariableInfo* _variablesTop;
//static size_t _numVariables = 0;
//
//static char _stringLiteralBuffer[STRING_LITERAL_BUFFER_SIZE];
//static char* _stringLiteralBufferEnd;
//
//static AllocateHeap _alloc;
//static FreeHeap _free;
//static ReallocateHeap _reallocate;
//static ForthPrintf _printf;
//static ForthPutChar _putchar;
//
//static size_t _ip = 0; // instruction pointer
//static char* _stringIp; // for interpreter mode
//
//static Cell _compiledWordsBytecode[COMPILED_WORDS_SIZE];
//static size_t _compiledWordsBytecodeLen = 0;
//
//static bool _nextByteCodeValueIsLiteral = false;
//
//static bool _nextTokenIsStringLiteral = false;
//
//
//
//// useful words
//char* _startupCode =
//// emit - prints a newline character
//": cr ( -- ) 10 emit ; "
//
//// prints a string
//": print ( array numToPrint -- ) "
//"0 do "
//"dup "
//"i + ( add i to the address of the string ) "
//"c@ emit ( dereference stack and emit character ) "
//"loop "
//"pop "
//"; "
//
//// converts a number of cells to that number of bytes
//": cells ( offset -- convertedToNumberOfCells ) cell * ; "
//
//// stores a value at the address and increments by one cell
//": , ( address valueToStore -- addressIncrementedByOneCell ) "
//"swap dup rot rot ! "
//"1 cells + "
//"; "
//
//// stores a value at the address and increments by one byte
//": c, ( address valueToStore -- addressIncrementedByOneByte ) "
//"swap dup rot rot c! "
//"1 + "
//"; "
//
//;
//
///* Forward Declarations ************************************************************************************** */
//
//ForthDoStringResult PrintIntStack();
//
///* Static functions ************************************************************************************** */
//
//#pragma region variables helpers
//
//static ForthDoStringResult PushVariableAddressOntoStack(int variableIndex) {
//	if (variableIndex >= _numVariables || variableIndex < 0) return RuntimeError;
//	Push_intStack((int)_variables[variableIndex].address);
//}
//
//static void AddIntVariable(const char* name) {
//	int namesize = strlen(name);
//	if (namesize >= MAX_WORD_NAME_LEN) {
//		_printf("Name too long - soz!");
//	}
//	for (int i = 0; i < _numVariables; i++) {
//		if (strcmp(_variables[i].name, name) == 0) {
//			return; // don't allocate a new one if there's already one by this name
//		}
//	}
//	VariableInfo vi;
//	strcpy_s(vi.name, namesize + 1, name);
//	vi.type = FInt;
//	vi.address = _alloc(SIZEOF_CELL);
//	vi.sizeCells = 1;
//	*(_variablesTop++) = vi;
//	_numVariables++;
//}
//
//#pragma endregion
//
//#pragma region integer stack helpers
//
//static ForthDoStringResult Pop1IntHelper(Cell* int1) {
//	size_t* _ = NULL;
//	char** __ = NULL;
//
//	if (Pop_intStack(int1) == FailStackEmpty) {
//		_printf("Pop1IntHelper, stack empty\n");
//		PrintIntStack(_, __);
//		return RuntimeError;
//	}
//	return HelperDoneOkay;
//}
//
//static ForthDoStringResult Pop2IntsHelper(Cell* int1, Cell* int2) {
//	size_t* _ = NULL;
//	char** __ = NULL;
//	if (Pop_intStack(int1) == FailStackEmpty) {
//		_printf("Pop2IntHelper failed, stack empty\n");
//		PrintIntStack(_, __);
//		return RuntimeError;
//	}
//	if (Pop_intStack(int2) == FailStackEmpty) {
//		_printf("Pop2IntHelper failed, stack empty\n");
//		PrintIntStack(_, __);
//		return RuntimeError;
//	}
//	return HelperDoneOkay;
//}
//
//static ForthDoStringResult Pop3IntsHelper(Cell* int1, Cell* int2, Cell* int3) {
//	size_t* _ = NULL;
//	char** __ = NULL;
//
//	if (Pop_intStack(int1) == FailStackEmpty) {
//		_printf("Pop3IntHelper failed, stack empty\n");
//		PrintIntStack(_, __);
//		return RuntimeError;
//	}
//	if (Pop_intStack(int2) == FailStackEmpty) {
//		_printf("Pop3IntHelper failed, stack empty\n");
//		PrintIntStack(_, __);
//		return RuntimeError;
//	}
//	if (Pop_intStack(int3) == FailStackEmpty) {
//		_printf("Pop3IntHelper failed, stack empty\n");
//		PrintIntStack(_, __);
//		return RuntimeError;
//	}
//	return HelperDoneOkay;
//}
//
//#pragma endregion
//
//
//#pragma region misc helpers
//
//char* SkipStringLiteral(char* nextToken) {
//
//	for (int i = 0; i < STRING_LITERAL_BUFFER_SIZE; i++) {
//		if (nextToken[i] == '\"') {
//			return nextToken + i;
//		}
//	}
//	return NULL;
//}
//
//void AddCFunctionWord(const char* name, CFunctionPtrWord cFunctionPtr, WordAvailability availability, ReturnValueFromProcessTokenPolicy policy) {
//	CompiledWordInfo info;
//	int baseLength = strlen(name);
//	strcpy_s(info.name, baseLength + 1, name);
//	info.namelen = baseLength;
//	info.isCFunction = true;
//	info.cFunctionPtr = cFunctionPtr;
//	info.numTokens = 0;
//	info.returnValuePolicy = policy;
//	info.availability = availability;
//	_compiledWordsInfos[_numCompiledWords++] = info;
//}
//
//#pragma endregion
//
///* Public functions ************************************************************************************** */
//
//void Forth_Initialise(AllocateHeap allocator, FreeHeap freeAllocated, ReallocateHeap reallocate, ForthPrintf fPrintf, ForthPutChar fPutchar)
//{
//	_intStackTop = _intStack;
//	memset(_compiledWordsInfos, 0, sizeof(CompiledWordInfo) * MAX_NUM_COMPILED_WORDS);
//
//	_variablesTop = _variables;
//	memset(_variables, 0, sizeof(VariableInfo) * MAX_NUM_VARIABLES);
//
//	_stringLiteralBufferEnd = _stringLiteralBuffer;
//	memset(_stringLiteralBuffer, 0, STRING_LITERAL_BUFFER_SIZE);
//
//	_returnStackTop = _returnStack;
//	memset(_returnStack, 0, RETURN_STACK_SIZE);
//
//
//	_alloc = allocator;
//	_free = freeAllocated;
//	_reallocate = reallocate;
//	_printf = fPrintf;
//	_putchar = fPutchar;
//	int tokens = 0;
//
//	// can't just give Forth_DoString a string literal because it alters the string
//	char* startupCodeBuf = _alloc(strlen(_startupCode) + 1);
//	strcpy_s(startupCodeBuf, strlen(_startupCode) + 1, _startupCode);
//	Forth_DoString(startupCodeBuf, &tokens);
//	_free(startupCodeBuf);
//}
//
//
//
//ForthDoStringResult Forth_DoString(const char* inputString, int* numTokens)
//{
//	char* delim = " \t\n";
//	char* nextToken;
//	const char* token = strtok_s(inputString, delim, &nextToken);
//	const char* firstToken = token;
//	while (token != NULL) {
//		(*numTokens)++;
//		if (strcmp(token, "s\"") == 0) {
//			char* newNext = SkipStringLiteral(nextToken); // skip the nextToken
//			if (newNext == NULL) {
//				_printf("you probably forgot the closing \" or you gave a string that was too long to .\"\n");
//				return CompileError;
//			}
//			nextToken = newNext;
//		}
//
//		token = strtok_s(NULL, delim, &nextToken);
//	}
//}
//
//void Forth_Teardown()
//{
//	for (int i = 0; i < _numVariables; i++) {
//		_free(_variables[i].address);
//	}
//}