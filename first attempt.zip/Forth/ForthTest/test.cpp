#include "pch.h"
extern "C" {
#include "../Forth/Forth.h"
}
#include <string>
#include <vector>
#include <stdarg.h>


static int DefaultTestPrintf(const char* format, ...) {
	va_list args;
	va_start(args, format);
	vprintf(format, args);
	return 1;
}

static int DefaultPutChar(int in) {
	putchar(in);
	return 1;
}

class ForthMemoryTestFixture : public ::testing::Test {
protected:
	static int timesFreed;
	static int timesAllocated;
	static int timesReallocated;
private:
	static void* MockMalloc(int numBytes) {
		timesAllocated++;
		return NULL;
	}

	static void MockFree(void* memory) {
		timesFreed++;
	}

	static void MockRealloc(void* memory, int numBytes) {
		timesReallocated++;
	}
public:
	ForthMemoryTestFixture() {
		// initialization code here
		Forth_Initialise(&MockMalloc, &MockFree, &MockRealloc, &DefaultTestPrintf, &DefaultPutChar);
	}

	void SetUp() {
		// code here will execute just before the test ensues
		timesFreed = 0;
		timesAllocated = 0;
		timesReallocated = 0;
	}

	void TearDown() {
		// code here will be called just after the test completes
		// ok to through exceptions from here if need be
	}

	~ForthMemoryTestFixture() {
		// cleanup any pending stuff, but no exceptions allowed
		Forth_Teardown();
	}
};

int ForthMemoryTestFixture::timesFreed;
int ForthMemoryTestFixture::timesAllocated;
int ForthMemoryTestFixture::timesReallocated;

TEST_F(ForthMemoryTestFixture, OnTeardown_FreeCalledForEachVariableDelcared) {
	std::string code = "variable variableName1 5 cell allot";
	std::string code1 = "variable variableName2 15 cell allot";
	std::string code2 = "variable variableName3";
	std::string code3 = "variable variableName4";
	int numTokens = 0;
	Forth_DoString(code.c_str(),&numTokens);
	numTokens = 0;
	Forth_DoString(code1.c_str(), &numTokens);
	numTokens = 0;
	Forth_DoString(code2.c_str(), &numTokens);
	numTokens = 0;
	Forth_DoString(code3.c_str(), &numTokens);
	ASSERT_EQ(timesFreed, 0);
	Forth_Teardown();
	ASSERT_EQ(timesFreed, 4);
}

TEST_F(ForthMemoryTestFixture, OnVariablesAllocated_AllocateCalledForEachUniqueName) {
	std::string code = "variable variableName1 5 cell allot";
	std::string code1 = "variable variableName2 15 cell allot";
	std::string code2 = "variable variableName3";
	std::string code3 = "variable variableName3";
	std::string code4 = "variable variableName3";
	const auto expectedTimesAllocated = 3;
	ASSERT_EQ(timesAllocated, 0);

	int numTokens = 0;
	Forth_DoString(code.c_str(), &numTokens);
	numTokens = 0;
	Forth_DoString(code1.c_str(), &numTokens);
	numTokens = 0;
	Forth_DoString(code2.c_str(), &numTokens);
	numTokens = 0;
	Forth_DoString(code3.c_str(), &numTokens);
	numTokens = 0;
	Forth_DoString(code4.c_str(), &numTokens);
	ASSERT_EQ(timesAllocated, expectedTimesAllocated);
	Forth_Teardown();
}

TEST_F(ForthMemoryTestFixture, OnVariablesAllocated_ReallocCalledForEachAllotWordRun) {
	std::string code = "variable variableName1 5 cell allot";
	std::string code1 = "variable variableName2 15 cell allot";
	std::string code2 = "variable variableName3";
	std::string code3 = "variable variableName3";
	std::string code4 = "variable variableName3";
	const auto expectedTimesReAllocated = 2;
	ASSERT_EQ(timesReallocated, 0);

	int numTokens = 0;
	Forth_DoString(code.c_str(), &numTokens);
	numTokens = 0;
	Forth_DoString(code1.c_str(), &numTokens);
	numTokens = 0;
	Forth_DoString(code2.c_str(), &numTokens);
	numTokens = 0;
	Forth_DoString(code3.c_str(), &numTokens);
	numTokens = 0;
	Forth_DoString(code4.c_str(), &numTokens);
	ASSERT_EQ(timesReallocated, expectedTimesReAllocated);
	Forth_Teardown();
}

class ForthDoStringTestFixture : public ::testing::Test {
protected:

	static std::vector<std::string> _printOutput;
	static int _testMemoryStore[1024];
	static char _sprintFBuffer[20000];
	static std::vector<char> _putcharOutput;
	void AssertOutputEqualsExpected(const std::vector<std::string>& expectedOutput, const std::vector<char>& expectedCharOutput) {
		ASSERT_EQ(expectedOutput.size(), _printOutput.size());
		ASSERT_EQ(expectedCharOutput.size(), _putcharOutput.size());

		auto i = 0;
		for (const auto& line : _printOutput) {
			ASSERT_EQ(line, expectedOutput[i]);
			i++;
		}
		i = 0;
		for (char c : _putcharOutput) {
			ASSERT_EQ(c, expectedCharOutput[i]);
			i++;
		}
	}
private:
	static void* TestAlloc(int numBytes) {
		return _testMemoryStore;
	}

	static void TestRealloc(void* memory, int numBytes) {
	}

	static void TestFree(void* memory) {
	}

public:
	ForthDoStringTestFixture() {
		// initialization code here
		Forth_Initialise(&TestAlloc, &TestFree, &TestRealloc, &TestPrintf, &TestPutChar);
	}

	void SetUp() {
		// code here will execute just before the test ensues
		_printOutput.clear();
		_putcharOutput.clear();
	}

	void TearDown() {
		// code here will be called just after the test completes
		// ok to through exceptions from here if need be
	}

	~ForthDoStringTestFixture() {
		// cleanup any pending stuff, but no exceptions allowed
	}

	// put in any custom data members that you need 
private:
	static int TestPrintf(const char* format, ...) {
		va_list args;
		va_start(args, format);
		vsprintf(_sprintFBuffer, format, args);
		_printOutput.push_back(std::string(_sprintFBuffer));
		return 1;
	}
	static int TestPutChar(int charVal) {
		_putcharOutput.push_back((char)charVal);
		return 1;
	}
};
std::vector<std::string> ForthDoStringTestFixture::_printOutput;
std::vector<char> ForthDoStringTestFixture::_putcharOutput;

char ForthDoStringTestFixture::_sprintFBuffer[20000];
int ForthDoStringTestFixture::_testMemoryStore[1024];

TEST_F(ForthDoStringTestFixture, FizzBuzz) {

	std::string code =
	": fizzbuzz "
		"16 0 do "
			"i 0 = if "
				"0 . "
			"else "
				"i 15 % 0 = if "
					"s\" FizzBuzz\" print cr "
				"else "
					"i 3 % 0 = if "
						"s\" Fizz\" print cr "
					"else "
						"i 5 % 0 = if "
							"s\" Buzz\" print cr "
						"else "
								"i . "
						"then "
					"then "
				"then "
			"then "
		"loop "
		"; ";

	std::vector<std::string> expectedOutput{
		"0\n",
		"1\n",
		"2\n",
		"4\n",
		"7\n",
		"8\n",
		"11\n",
		"13\n",
		"14\n",
	};

	std::vector<char> expectedCharsOutput = {
		'F','i','z','z','\n',
		'B', 'u','z','z','\n',
		'F','i','z','z','\n',
		'F','i','z','z','\n',
		'B', 'u','z','z','\n',
		'F','i','z','z','\n',
		'F','i','z','z','B', 'u','z','z','\n',
	};
	int numStrings = 0;
	Forth_DoString(code.c_str(), &numStrings);
	numStrings = 0;
	Forth_DoString("fizzbuzz", &numStrings);

	AssertOutputEqualsExpected(expectedOutput, expectedCharsOutput);
}


TEST_F(ForthDoStringTestFixture, Emit) {
	std::string code = ": jim 74 emit 105 emit 109 emit 10 emit ;";
	std::vector<std::string> expectedOutput = {
	};
	std::vector<char> expectedCharsOutput = {
		'J','i','m','\n'
	};

	int numStrings = 0;
	Forth_DoString(code.c_str(), &numStrings);
	numStrings = 0;
	Forth_DoString("jim", &numStrings);
	AssertOutputEqualsExpected(expectedOutput, expectedCharsOutput);
}

TEST_F(ForthDoStringTestFixture, ArrayTest) {
	std::string code =
		": cells cell * ; "
		"variable array 5 cell allot "
		": array-test "
		"4 0 do "
		"420 i + array i cells + ! "
		"loop "
		"4 0 do "
		"array cell i * + @ . "
		"loop "
		"; ";
	std::vector<std::string> expectedOutput = {
		"420\n","421\n","422\n","423\n"
	};
	std::vector<char> expectedCharsOutput = {
	};

	int numStrings = 0;
	Forth_DoString(code.c_str(), &numStrings);
	numStrings = 0;
	std::string code2 = "array-test";
	Forth_DoString(code2.c_str(), &numStrings);
	AssertOutputEqualsExpected(expectedOutput, expectedCharsOutput);

	ASSERT_EQ(_testMemoryStore[0], 420);
	ASSERT_EQ(_testMemoryStore[1], 421);
	ASSERT_EQ(_testMemoryStore[2], 422);
	ASSERT_EQ(_testMemoryStore[3], 423);

}

TEST_F(ForthDoStringTestFixture, ArrayTestVariableInsideWord) {
	// same as previous test but the variable declaration is inside the compiled word
	std::string code =
		": cells cell * ; "
		": array-test "
		"variable array 5 cell allot "
		"4 0 do "
		"420 i + array i cells + ! "
		"loop "
		"4 0 do "
		"array cell i * + @ . "
		"loop "
		"; ";
	std::vector<std::string> expectedOutput = {
		"420\n","421\n","422\n","423\n"
	};
	
	std::vector<char> expectedCharsOutput = {
	
	};

	int numStrings = 0;
	Forth_DoString(code.c_str(), &numStrings);
	numStrings = 0;
	std::string code2 = "array-test";
	Forth_DoString(code2.c_str(), &numStrings);
	AssertOutputEqualsExpected(expectedOutput, expectedCharsOutput);

	ASSERT_EQ(_testMemoryStore[0], 420);
	ASSERT_EQ(_testMemoryStore[1], 421);
	ASSERT_EQ(_testMemoryStore[2], 422);
	ASSERT_EQ(_testMemoryStore[3], 423);

}

TEST_F(ForthDoStringTestFixture, FibonacciTest) {

	std::string code =
	": fib "
		"twodup "
		"+ "
		"; "
	": fibLoop "
		"0 do "
		"fib "
		"rot "
		"pop "
		"dup "
		". "
		"loop "
		"; "
	": computeFib "
		"0 1 "
		"rot ( rotate to get the users number on the top of the stack for the do loop ) "
		"fibLoop "
		"; ";

	std::vector<std::string> expectedOutput = {
		"1\n",
		"2\n",
		"3\n",
		"5\n",
		"8\n",
		"13\n",
		"21\n"
	};

	std::vector<char> expectedCharsOutput = {

	};

	int numStrings = 0;
	Forth_DoString(code.c_str(), &numStrings);
	numStrings = 0;
	std::string code2 = "7 computeFib";
	Forth_DoString(code2.c_str(), &numStrings);
	AssertOutputEqualsExpected(expectedOutput, expectedCharsOutput);
}

TEST_F(ForthDoStringTestFixture, InterpretedIfTest_SingleNested_EqualsConditional) {

	std::vector<std::string> expectedOutput = {
		"1\n",
		"2\n"
	};

	std::vector<char> expectedCharsOutput = {

	};

	std::string code = "1 2 = if 2 . else 1 . then";
	std::string code2 = "2 2 = if 2 . else 1 . then";

	int numStrings = 0;
	Forth_DoString(code.c_str(), &numStrings);
	numStrings = 0;
	Forth_DoString(code2.c_str(), &numStrings);
	AssertOutputEqualsExpected(expectedOutput, expectedCharsOutput);
}

TEST_F(ForthDoStringTestFixture, InterpretedDoTest_SingleNested) {

	std::vector<std::string> expectedOutput = {
		"0\n",
		"1\n",
		"2\n",
		"3\n",
		"4\n",
	};

	std::vector<char> expectedCharsOutput = {

	};

	std::string code = "5 0 do i . loop";

	int numStrings = 0;
	Forth_DoString(code.c_str(), &numStrings);
	AssertOutputEqualsExpected(expectedOutput, expectedCharsOutput);
}

TEST_F(ForthDoStringTestFixture, InterpretedDoTest_DoubleNested) {

	std::vector<std::string> expectedOutput = {
		"0\n",
		"1\n",
		"2\n",
		"0\n",
		"1\n",
		"2\n",
		"0\n",
		"1\n",
		"2\n",
	};
	std::string code = "3 0 do 3 0 do i . loop loop";
	std::vector<char> expectedCharsOutput = {

	};

	int numStrings = 0;
	Forth_DoString(code.c_str(), &numStrings);
	AssertOutputEqualsExpected(expectedOutput, expectedCharsOutput);
}

TEST_F(ForthDoStringTestFixture, LoopWithIfWithLoop) {

	std::vector<std::string> expectedOutput = {
		"0\n",
		"1\n",
		"2\n"
	};
	
	std::vector<char> expectedCharsOutput = {
		'j',
		'i',
		'm'
	};

	std::string code = 
		"2 0 do "
			"i 1 = if "
				"3 0 do "
					"i . "
				"loop "
			"else "
				"s\" jim\" print "
			"then "
		"loop ";


	int numStrings = 0;
	Forth_DoString(code.c_str(), &numStrings);
	AssertOutputEqualsExpected(expectedOutput, expectedCharsOutput);
}

TEST_F(ForthDoStringTestFixture, LoopWithIfWithLoopCompiled) {

	std::vector<std::string> expectedOutput = {
		"0\n",
		"1\n",
		"2\n"
	};
	
	std::vector<char> expectedCharsOutput = {
		'j',
		'i',
		'm',
	};

	std::string code =
		": test "
		"2 0 do "
			"i 1 = if "
				"3 0 do "
					"i . "
				"loop "
			"else "
				"s\" jim\" print "
			"then "
		"loop "
		"; "
		"test ";


	int numStrings = 0;
	Forth_DoString(code.c_str(), &numStrings);
	AssertOutputEqualsExpected(expectedOutput, expectedCharsOutput);
}

TEST_F(ForthDoStringTestFixture, CommaWordTest) { 

	std::vector<std::string> expectedOutput = {
		"1\n",
		"2\n",
		"3\n",
		"4\n",
	};

	std::vector<char> expectedCharsOutput = {
	};

	std::string code =
		"variable var 5 cell allot "
		"var 1 , 2 , 3 , 4 , "
		": test "
			"var @ . "
			"var 1 cells + @ . "
			"var 2 cells + @ . "
			"var 3 cells + @ . "
			"; "
		"test ";

	int numStrings = 0;
	Forth_DoString(code.c_str(), &numStrings);
	AssertOutputEqualsExpected(expectedOutput, expectedCharsOutput);
}

TEST_F(ForthDoStringTestFixture, CbarCommaWordTest) {

	std::vector<std::string> expectedOutput = {
		"1\n",
		"2\n",
		"3\n",
		"4\n",
	};

	std::vector<char> expectedCharsOutput = {
	};

	std::string code =
		"variable var 5 cell allot "
		"var 1 c, 2 c, 3 c, 4 c, "
		": test "
			"var c@ . "
			"var 1 + c@ . "
			"var 2 + c@ . "
			"var 3 + c@ . "
		"; "
		"test ";

	int numStrings = 0;
	Forth_DoString(code.c_str(), &numStrings);
	AssertOutputEqualsExpected(expectedOutput, expectedCharsOutput);
}