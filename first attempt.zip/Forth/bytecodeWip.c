#include "Forth.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>

/*

bytecode version WIP

Forth interpreter - © Jim Marshall 2022

Loosly based on this youtubers videos on writing a forth interpreter: Thanks!
https://www.youtube.com/@JoeKreydt

Example forth code for doing fibonacci sequence

: fib
	twodup
	+
;

: fibLoop
	0 do
		fib
		rot
		pop
		dup
		.
	loop
;

: computeFib
	0 1
	rot ( rotate to get the users number on the top of the stack for the do loop )
	fibLoop
;

fizz buzz

: fizzbuzz
	0 do
		i 0 = if
			0 .
		else
			i 15 % 0 = if
				." fizzbuzz"
			else
				i 3 % 0 = if
					." fizz"
				else
					i 5 % 0 = if
						." buzz"
					else
						i .
					then
				then
			then
		then
	loop
;

array test

: cells cell * ;
variable array 5 cell allot

: array-test
	4 0 do
		420 i + array i cells + !
	loop
	4 0 do
		array cell i * + @ .
	loop
;

emit test

: jim 74 emit 105 emit 109 emit 10 emit ;

character manipulation
: cr 10 emit ;

: print  ( array numToPrint -- )
	0 do 
		dup
		i + ( add i to the address of the string ) 
		c@ emit ( dereference stack and emit character )
	loop 
	pop
;
: test 256 0 do s" hello" twodup + dup i swap ! 1 + 10 swap ! 1 + print loop ; 

variable jim 4 cell allot
74 jim c!
105 jim 1 + c!
109 jim 2 + c!
10 jim 3 + c!
jim 4 print


*/


/* Typedefs ************************************************************************************** */

typedef int32_t Cell;

/* Defines ************************************************************************************** */

#define Kb (1024)
#define INT_STACK_SIZE 128
#define COMPILED_WORDS_SIZE (1024 * Kb)
#define MAX_WORD_NAME_LEN (64)
#define MAX_NUM_COMPILED_WORDS (1000)
#define CONTROL_FLOW_STACK_SIZE 128
#define LOOP_STACK_SIZE 128
#define MAX_NUM_VARIABLES 256
#define STRING_LITERAL_BUFFER_SIZE Kb

#define NEXT_TOKEN_IS_LITERAL_WORD 0
#define NEXT_TOKEN_IS_VARIABLE_WORD 1
#define STRING_LITERAL_WITH_DOT_TOKEN 2
#define STRING_LITERAL_TOKEN 3

// replace 4 with the a define for cell size
#define MAX_OUPUTTED_TOKENS_FROM_COMPILE ( STRING_LITERAL_BUFFER_SIZE / 4)

#define BYTECODE_ALIGNMENT 4

#define COMPILE_BYTECODE 

#define SIZEOF_CELL sizeof(Cell)

/* Typedefs ************************************************************************************** */

typedef enum {
	IntCell,
	// FloatCell
}AllotType;

typedef enum {
	FInt,
	FIntArray,
	FString
}VariableType;

typedef enum {
	false,
	true
}bool;

typedef enum {
	NoFlagsSet = 1,
	CompileFlagSet = 2,
	CommentFlagSet = 4,
	CurrentNestIsNotReadable = 8,
	ParsingStringLiteralFlag = 16

}WordAvailability;

typedef enum {
	CompiledWordAddSuccess,
	CompiledWordAddFailure
}AddToCompiledWordResult;

typedef enum {
	Pass,
	FailStackEmpty,
	FailStackFull
}StackChangeResult;

typedef enum {
	IfRuntimeError,
	Force, // used for words that set the read position of the token stream - such as loop - these will return ExecutionPositionChangedByWord
	IfChangedExecutionPosition
}ReturnValueFromProcessTokenPolicy;

typedef ForthDoStringResult(*CFunctionPtrWord)(size_t* tokenNumber, char** token);

typedef struct {
	Cell* bytecode;
	size_t namelen;
	char name[MAX_WORD_NAME_LEN];
	bool tokenized;
	bool isCFunction;
	CFunctionPtrWord cFunctionPtr;
	size_t numTokens;
	WordAvailability availability;
	ReturnValueFromProcessTokenPolicy returnValuePolicy;
}CompiledWordInfo;

typedef struct {
	size_t tokenNumber;
	char* tokenToStartLoop;
	Cell i;
	Cell limit;
}LoopInfo;

typedef struct {
	char name[MAX_WORD_NAME_LEN];
	VariableType type;
	size_t sizeCells;
	size_t sizeBytes;
	void* address;
}VariableInfo;

/* Static variables ************************************************************************************** */

static CompiledWordInfo _compiledWordsInfos[MAX_NUM_COMPILED_WORDS];
static int _numCompiledWords = 0;

static bool _commentFlag = false;
static bool _compileFlag = false;
static bool _settingVariableFlag = false;
static bool _parsingStringLiteralFlag = false;
static bool _printAfterFinishedParsingStringLiteral = false;

static bool _controlFlowStack[CONTROL_FLOW_STACK_SIZE];
static bool* _controlFlowStackTop;
static size_t _controlFlowStackSize = 0;

static LoopInfo _loopStack[LOOP_STACK_SIZE];
static LoopInfo* _loopStackTop;
static size_t _loopStackSize;

static Cell _intStack[INT_STACK_SIZE];
static Cell* _intStackTop;
static size_t _intStackSize;

static VariableInfo _variables[MAX_NUM_VARIABLES];
static VariableInfo* _variablesTop;
static size_t _numVariables = 0;

static char _stringLiteralBuffer[STRING_LITERAL_BUFFER_SIZE];
static char* _stringLiteralBufferEnd;

static AllocateHeap _alloc;
static FreeHeap _free;
static ReallocateHeap _reallocate;
static ForthPrintf _printf;

static Cell _compiledWordsBytecode[COMPILED_WORDS_SIZE];
static size_t _compiledWordsBytecodeLen = 0;

// bytecode flags
static bool _nextByteCodeValueIsLiteral = false;
static bool _nextByteCodeValueIsVariable = false;

static bool _nextTokenIsStringLiteral = false;


static bool _runningCompiledCode = false;
/* Forward Declarations ************************************************************************************** */

ForthDoStringResult PrintIntStack();

/* Static functions ************************************************************************************** */

#pragma region variables helpers

static ForthDoStringResult PushVariableAddressOntoStack(int variableIndex) {
	if (variableIndex >= _numVariables || variableIndex < 0) return RuntimeError;
	PushInt((int)_variables[variableIndex].address);
}

static void AddIntVariable(const char* name) {
	int namesize = strlen(name);
	if (namesize >= MAX_WORD_NAME_LEN) {
		_printf("Name too long - soz!");
	}
	for (int i = 0; i < _numVariables; i++) {
		if (strcmp(_variables[i].name, name) == 0) {
			return; // don't allocate a new one if there's already one by this name
		}
	}
	VariableInfo vi;
	strcpy_s(vi.name, namesize + 1, name);
	vi.type = FInt;
	vi.address = _alloc(SIZEOF_CELL);
	vi.sizeCells = 1;
	*(_variablesTop++) = vi;
	_numVariables++;
}

#pragma endregion

#pragma region loop stack helpers

static LoopInfo* PeekLoopStack() {
	return (_loopStackTop - 1);
}

static StackChangeResult PushLoopStack(const LoopInfo* loop) {
	if (_loopStackSize >= LOOP_STACK_SIZE) {
		return CompiledWordAddFailure;
	}

	*(_loopStackTop++) = *loop;
	_loopStackSize++;

	return Pass;
}

static StackChangeResult PopLoopStack(LoopInfo* loop) {
	if (_loopStackTop == _loopStack) {
		return FailStackEmpty;
	}

	*loop = *(--_loopStackTop);
	_loopStackSize--;

	return Pass;
}

#pragma endregion

#pragma region control flow stack helpers

static int PeekControlFlowStack() {
	return *(_controlFlowStackTop - 1);
}

static StackChangeResult PushControlFlow(bool val) {
	if (_controlFlowStackTop >= _controlFlowStack + CONTROL_FLOW_STACK_SIZE) {
		return FailStackFull;
	}
	*(_controlFlowStackTop++) = val;
	_controlFlowStackSize++;
	return Pass;
}

static StackChangeResult PopControlFlow(bool* output) {
	if (_controlFlowStackTop == _controlFlowStack) {
		return FailStackEmpty;
	}
	output = --_controlFlowStackTop;
	_controlFlowStackSize--;
	return Pass;
}

#pragma endregion

#pragma region integer stack helpers


static StackChangeResult PushInt(Cell val) {
	if (_intStackTop >= _intStack + INT_STACK_SIZE) {
		return FailStackFull;
	}
	*(_intStackTop++) = val;
	_intStackSize++;
	return Pass;
}

static StackChangeResult PopInt(Cell* output) {
	if (_intStackTop == _intStack) {
		return FailStackEmpty;
	}
	*output = *(--_intStackTop);
	_intStackSize--;
	return Pass;
}

static ForthDoStringResult Pop1IntHelper(Cell* int1) {
	size_t* _ = NULL;
	char** __ = NULL;

	if (PopInt(int1) == FailStackEmpty) {
		_printf("Pop1IntHelper, stack empty\n");
		PrintIntStack(_, __);
		return RuntimeError;
	}
	return HelperDoneOkay;
}

static ForthDoStringResult Pop2IntsHelper(Cell* int1, Cell* int2) {
	size_t* _ = NULL;
	char** __ = NULL;
	if (PopInt(int1) == FailStackEmpty) {
		_printf("Pop2IntHelper failed, stack empty\n");
		PrintIntStack(_, __);
		return RuntimeError;
	}
	if (PopInt(int2) == FailStackEmpty) {
		_printf("Pop2IntHelper failed, stack empty\n");
		PrintIntStack(_, __);
		return RuntimeError;
	}
	return HelperDoneOkay;
}

static ForthDoStringResult Pop3IntsHelper(Cell* int1, Cell* int2, Cell* int3) {
	size_t* _ = NULL;
	char** __ = NULL;

	if (PopInt(int1) == FailStackEmpty) {
		_printf("Pop3IntHelper failed, stack empty\n");
		PrintIntStack(_, __);
		return RuntimeError;
	}
	if (PopInt(int2) == FailStackEmpty) {
		_printf("Pop3IntHelper failed, stack empty\n");
		PrintIntStack(_, __);
		return RuntimeError;
	}
	if (PopInt(int3) == FailStackEmpty) {
		_printf("Pop3IntHelper failed, stack empty\n");
		PrintIntStack(_, __);
		return RuntimeError;
	}
	return HelperDoneOkay;
}

#pragma endregion

#pragma region Built in forth words

static ForthDoStringResult PrintIntStack(size_t* _, char** __) {
	_printf("[ ");
	for (Cell* ptr = _intStack; ptr < _intStackTop; ptr++) {
		_printf("%i", *ptr);
		if (ptr < _intStackTop - 1) {
			_printf(", ");
		}
	}
	_printf(" ]\n");
	return TokenDoneOkay;
}

static ForthDoStringResult Modulo(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt(int2 % int1);
	return TokenDoneOkay;
}

static ForthDoStringResult Add(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt(int1 + int2);
	return TokenDoneOkay;
}

static ForthDoStringResult Subtract(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt(int2 - int1);
}

static ForthDoStringResult Multiply(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt(int1 * int2);
}

static ForthDoStringResult Divide(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt(int2 / int1);
}

static ForthDoStringResult Equal(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt((int1 == int2) ? -1 : 0);
}

static ForthDoStringResult NotEqual(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt((int1 != int2) ? -1 : 0);
}

static ForthDoStringResult And(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt(((int1 == -1) && (int2 == -1)) ? -1 : 0);
}

static ForthDoStringResult Or(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt(((int1 == -1) || (int2 == -1)) ? -1 : 0);
}

static ForthDoStringResult GreaterThan(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt((int2 > int1) ? -1 : 0);
}

static ForthDoStringResult LessThan(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt((int2 < int1) ? -1 : 0);
}

static ForthDoStringResult GreaterThanOrEqual(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt((int2 >= int1) ? -1 : 0);
}

static ForthDoStringResult LessThanOrEqual(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt((int2 <= int1) ? -1 : 0);
}

static ForthDoStringResult Dup(size_t* _, char** __) {
	if (_intStackTop == _intStack) {
		_printf("empty stack dumbass\n");
		return RuntimeError;
	}
	PushInt(*(_intStackTop - 1));
}

static ForthDoStringResult Rot(size_t* _, char** __) {
	Cell int1, int2, int3;
	Pop3IntsHelper(&int1, &int2, &int3);
	PushInt(int2);
	PushInt(int1);
	PushInt(int3);
}

static ForthDoStringResult TwoDup(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	PushInt(int2);
	PushInt(int1);
	PushInt(int2);
	PushInt(int1);
}

static ForthDoStringResult Swap(size_t* _, char** __) {
	if (_intStackTop - 2 < _intStack) return RuntimeError;
	Cell* int1;
	Cell* int2;
	int1 = _intStackTop - 1;
	int2 = _intStackTop - 2;
	Cell int1Copy = *int1;
	*int1 = *int2;
	*int2 = int1Copy;
}

static ForthDoStringResult PushI(size_t* _, char** __) {
	if (_loopStackSize == 0) {
		_printf("not currently in a loop\n");
		return RuntimeError;
	}
	int i = PeekLoopStack()->i;
	PushInt(i);
}

static ForthDoStringResult ifIf(size_t* _, char** __) {
	bool conditionBool;
	bool currentNestIsReadable;
	if (_controlFlowStackSize > 0) {
		currentNestIsReadable = PeekControlFlowStack();
		if (currentNestIsReadable) {
			if (_intStackSize >= 1) {
				int conditionVal;
				StackChangeResult res = PopInt(&conditionVal);
				if (res != Pass) {
					return RuntimeError;
				}
				if (conditionVal > -1) {
					conditionBool = false;
				}
				else {
					conditionBool = true;
				}
			}
			else {
				_printf("you need at least one value on the integer stack dipshit\n");
				//conditionBool = currentNestIsReadable;
				return RuntimeError;
			}
		}
		else {
			conditionBool = false;
		}
	}
	else {
		if (_intStackSize > 0) {
			Cell conditionVal;
			StackChangeResult res = PopInt(&conditionVal);
			if (res != Pass) {
				return RuntimeError;
			}
			if (conditionVal > -1) {
				conditionBool = false;
			}
			else {
				conditionBool = true;
			}
		}
		else {
			_printf("no val on integer stack dipshit\n");
			//conditionBool = currentNestIsReadable;
			return RuntimeError;
		}
	}
	if (PushControlFlow(conditionBool) != Pass) {
		return RuntimeError;
	}
	return TokenDoneOkay;
}

static ForthDoStringResult ifElse(size_t* _, char** __) {
	bool currentNestIsReadable;
	bool parentNestIsReadable;
	if (_controlFlowStackSize > 0) {
		bool x = PeekControlFlowStack();
		currentNestIsReadable = x;
		bool _;
		if (currentNestIsReadable) {

			if (x == true) {
				if (PopControlFlow(&_) != Pass) return RuntimeError;
				if (PushControlFlow(false) != Pass) return RuntimeError;
			}
			else {
				if (PopControlFlow(&_) != Pass) return RuntimeError;
				if (PushControlFlow(true) != Pass) return RuntimeError;

			}
		}
		else {
			if (_controlFlowStackSize >= 2) {
				bool secondToLast = *(_controlFlowStackTop - 2);
				parentNestIsReadable = secondToLast;
				if (parentNestIsReadable) {
					if (PopControlFlow(&_) != Pass) return RuntimeError;
					if (PushControlFlow(true) != Pass) return RuntimeError;
				}
			}
			else {
				if (PopControlFlow(&_) != Pass) return RuntimeError;
				if (PushControlFlow(true) != Pass) return RuntimeError;

			}
		}
	}
	else {
		_printf("Control flow stack is empty else should be proceded by if - Dont' quit your day job!!");
		return RuntimeError;
	}

	return TokenDoneOkay;
}

static ForthDoStringResult ifThen(size_t* _, char** __) {
	bool ___;
	if (_controlFlowStackSize == 0) {
		_printf("then should be proceded by if.");
		return RuntimeError;
	}
	if (PopControlFlow(&___) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult Do(size_t* tokenNumber, char** token) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	LoopInfo info;
	info.limit = int2;
	info.i = int1;
	info.tokenNumber = (*tokenNumber) - 1; // gets incremented after ProcessWord returns
#ifndef COMPILE_BYTECODE
	info.tokenToStartLoop = (*token);
#endif
	PushLoopStack(&info);
}

static ForthDoStringResult Loop(size_t* tokenNumber, char** token) {
	if (_loopStackSize == 0) {
		_printf("loop needs to match up with do");
		return RuntimeError;
	}

	LoopInfo info;
	if (PopLoopStack(&info) != Pass) return RuntimeError;

	info.i++;
	if (info.i >= info.limit) {
		// finished loop, leave loop stack empty
		return TokenDoneOkay;
	}
	else {
		// re-push the limit and i onto the data stack and return to the start token

		PushInt(info.limit);
		PushInt(info.i);
		*tokenNumber = info.tokenNumber;
#ifndef COMPILE_BYTECODE
		* token = info.tokenToStartLoop;
#endif
	}
	return ExecutionPositionChangedByWord;

}

static ForthDoStringResult PopWord(size_t* _, char** __) {
	Cell ___;
	if (PopInt(&___) != Pass) return RuntimeError;
}

void DebugPrintWordContents(const char* contents, int numTokens) {
	const char* token = contents;
	for (int i = 0; i < numTokens; i++) {
		_printf(token);
		_printf(" ");
		token += strlen(token) + 1;
	}
	_printf("\n");
}

static ForthDoStringResult DebugPrintCompiledWords(size_t* _, char** __) {
	for (int i = 0; i < _numCompiledWords; i++) {
		_printf("%i name: %s", i, _compiledWordsInfos[i].name);
		//DebugPrintWordContents(_compiledWordsInfos[i].contents, _compiledWordsInfos[i].numTokens);
		_printf(" num tokens: %i", _compiledWordsInfos[i].numTokens);
		_printf(" tokenized: %s\n", _compiledWordsInfos[i].tokenized ? "true" : "false");
	}
	_printf("\n");
}

static ForthDoStringResult Assign(size_t* _, char** __) {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;
	*((Cell*)int1) = int2;
	return TokenDoneOkay;
}

static ForthDoStringResult Dereference(size_t* _, char** __) {
	Cell int1 = 0;
	if (Pop1IntHelper(&int1) != HelperDoneOkay) return RuntimeError;
	PushInt(*((Cell*)int1));
	return TokenDoneOkay;
}

static ForthDoStringResult AssignChar() {
	Cell int1, int2;
	if (Pop2IntsHelper(&int1, &int2) != HelperDoneOkay) return RuntimeError;

	*((char*)int1) = (char)int2;
	return TokenDoneOkay;
}

static ForthDoStringResult DereferenceChar(size_t* _, char** __) {
	Cell int1 = 0;
	if (Pop1IntHelper(&int1) != HelperDoneOkay) return RuntimeError;
	PushInt(*((char*)int1));
	return TokenDoneOkay;
}

static ForthDoStringResult Dot(size_t* _, char** __) {
	Cell int1 = 0;
	if (Pop1IntHelper(&int1) != HelperDoneOkay) return RuntimeError;
	_printf("%i\n", int1);
	return TokenDoneOkay;

}

static ForthDoStringResult StartCompile(size_t* _, char** __) {
	_compileFlag = 1;
	_compiledWordsInfos[_numCompiledWords].bytecode = _compiledWordsBytecode + _compiledWordsBytecodeLen;
	_compiledWordsInfos[_numCompiledWords].numTokens = 0;
	_compiledWordsInfos[_numCompiledWords].numTokens = false;
	return TokenDoneOkay;
}

static ForthDoStringResult EndCompile(size_t* _, char** token) {
	_compileFlag = 0;
	_compiledWordsInfos[_numCompiledWords].tokenized = true;
	_compiledWordsInfos[_numCompiledWords].isCFunction = false;
	_compiledWordsInfos[_numCompiledWords].cFunctionPtr = NULL;
	_compiledWordsInfos[_numCompiledWords].availability = NoFlagsSet;
	_numCompiledWords++;
	return TokenDoneOkay;

}

static ForthDoStringResult StartCommentWord(size_t* _, char** __) {
	if (_commentFlag) return CompileError;
	_commentFlag = true;
	return TokenDoneOkay;
}

static ForthDoStringResult EndCommentWord(size_t* _, char** __) {
	if (!_commentFlag) return CompileError;
	_commentFlag = false;
	return TokenDoneOkay;
}

static ForthDoStringResult SetVariableFlagWord(size_t* _, char** __) {
	if (_settingVariableFlag) return RuntimeError;
	_settingVariableFlag = true;
	return TokenDoneOkay;
}

static ForthDoStringResult CellsWord(size_t* _, char** __) {
	if (PushInt(SIZEOF_CELL) != Pass) return RuntimeError;
	return TokenDoneOkay;
}

static ForthDoStringResult AllotWord(size_t* _, char** __) {
	Cell cellSizeInBytes, sizeInCells;
	if (Pop2IntsHelper(&cellSizeInBytes, &sizeInCells) != HelperDoneOkay) return RuntimeError;
	VariableInfo* lastVar = _variablesTop - 1;
	sizeInCells++;
	if (lastVar->sizeCells != sizeInCells) {
		lastVar->sizeCells = sizeInCells;
		_reallocate(lastVar->address, sizeInCells * cellSizeInBytes);
	}
}

static ForthDoStringResult EmitWord(size_t* _, char** token) {
	Cell int1;
	if (Pop1IntHelper(&int1) != HelperDoneOkay) return RuntimeError;
	char c = (char)int1;

	_printf("%c", c);
}

static ForthDoStringResult NextTokenIsLiteralWord(size_t* _, char** token) {
	_nextByteCodeValueIsLiteral = true;
}

static ForthDoStringResult NextTokenIsVariableWord(size_t* _, char** token) {
	_nextByteCodeValueIsVariable = true;
}

#pragma endregion

#pragma region core interpreter

static void CompileTokenToBytecode(char* token, Cell* output, int* numTokensOutputted) {
	/*
		compiles text token into bytecode - one text token may emit several bytecode tokens

		> words compile to their index

		> variable names compile to (1, variable index) - the 1 token signifies that the next token is a variable name - possible todo, unify word and variable dictionaries

		> currently can't use the variable word in compile mode - to implement this I'll probably have to store the variable name in the same way as string literals

		> "3"  would compile to 0, 3 (in this program the word 0 signifies the next token is a number literal)

		> Inlined strings are compiled into the bytecode for the word like this :

																																   <-----------------------(n cells)-------------------------------->
		|CELL0 (or another token signifying a string literal follows)  |CELL1 (signifies number of cells containing string bytes) |CELL2               | CELL3           |  CELL4          |         |
		|    value 2                                                   | length of string, n cells                                | data for string    | data for string | data for string | ect...  |

		> the cells themselves are aligned according to BYTECODE_ALIGNMENT

	*/
	* numTokensOutputted = 0;
	if (_nextTokenIsStringLiteral) {
		Cell stringSizeBytes = strlen(token);
		Cell cellsRequired = stringSizeBytes % BYTECODE_ALIGNMENT ? (stringSizeBytes / SIZEOF_CELL) + 1 : stringSizeBytes / SIZEOF_CELL;
		*numTokensOutputted = cellsRequired + 1; // +1 for the next cell which tells how many the string takes up
		output[0] = cellsRequired;
		for (int i = 1; i < cellsRequired + 1; i++) {
			output[i] = *((Cell*)token);
			token += SIZEOF_CELL;
		}
		return;
	}
	for (int i = 0; i < _numCompiledWords; i++) {
		if (strcmp(_compiledWordsInfos[i].name, token) == 0) {
			*numTokensOutputted = 1;
			*output = (Cell)i;
			return;
		}
	}
	int parsed = atoi(token);
	if (strcmp(token, "0") == 0 || parsed > 0) {
		*numTokensOutputted = 2;
		output[0] = NEXT_TOKEN_IS_LITERAL_WORD;
		output[1] = (Cell)parsed;
		return;
	}
	for (int i = 0; i < _numVariables; i++) {
		if (strcmp(_variables[i].name, token) == 0) {
			*numTokensOutputted = 2;
			output[0] = NEXT_TOKEN_IS_VARIABLE_WORD;
			output[1] = (Cell)i;
			return;
		}
	}

}

static ForthDoStringResult CompileToByteCode(const char* token) {

	Cell outputtedTokens[MAX_OUPUTTED_TOKENS_FROM_COMPILE];
	int numTokensOutputted = 0;
	if (_compiledWordsInfos[_numCompiledWords].namelen == 0) {
		//AddNullCharacterToCompiledWordsData();
		if (atoi(token) != 0) {
			_printf("You can't name a word with a number soft lad");
			return CompileError;
		}
		_compiledWordsInfos[_numCompiledWords].namelen = strlen(token);
		memcpy(_compiledWordsInfos[_numCompiledWords].name, token, _compiledWordsInfos[_numCompiledWords].namelen);
		_compiledWordsInfos[_numCompiledWords].name[_compiledWordsInfos[_numCompiledWords].namelen] = '\0';
	}
	else {
		CompileTokenToBytecode(token, outputtedTokens, &numTokensOutputted);
		_compiledWordsInfos[_numCompiledWords].numTokens += numTokensOutputted;
		for (int i = 0; i < numTokensOutputted; i++) {
			_compiledWordsBytecode[_compiledWordsBytecodeLen++] = outputtedTokens[i];
		}
	}
}

static ForthDoStringResult StartParsingStringBase(bool printResult) {
	_printAfterFinishedParsingStringLiteral = printResult;
	if (_parsingStringLiteralFlag) {
		_printf("probably an unclosed .\"\n");
		return CompileError;
	}
	_parsingStringLiteralFlag = true;
	return TokenDoneOkay;
}

static ForthDoStringResult StartParsingStringWithDot() {
	return StartParsingStringBase(true);
}

static ForthDoStringResult StartParsingString() {
	return StartParsingStringBase(false);
}

void StopParsingString(const char* token) {
	char* t = token;
	*(_stringLiteralBufferEnd++) = '\0';
	if (!_compileFlag) {
		if (_printAfterFinishedParsingStringLiteral) {
			_printf("%s\n", _stringLiteralBuffer);
		}
		else {
			PushInt(_stringLiteralBuffer);
			PushInt(strlen(_stringLiteralBuffer));
		}
	}
	_stringLiteralBufferEnd = _stringLiteralBuffer;
	_parsingStringLiteralFlag = false;
}

static ForthDoStringResult AddToStringLiteralBuffer(const char* token) {
	for (int i = 0; i < STRING_LITERAL_BUFFER_SIZE; i++) {
		if (token[i] == '\"') {
			StopParsingString(token);
			return TokenDoneOkay;
		}
		*(_stringLiteralBufferEnd++) = token[i];
	}
	_printf("string too long or you forgot to end it \n");
	return CompileError;
}

static ForthDoStringResult RunWord(int wordIndex) {
#ifdef COMPILE_BYTECODE
	ForthDoStringResult res = DoBytecodeWord(_compiledWordsInfos[wordIndex].bytecode, _compiledWordsInfos[wordIndex].numTokens);
#else
	ForthDoStringResult res = DoPreTokenizedString(_compiledWordsInfos[wordIndex].contents,
		_compiledWordsInfos[wordIndex].numTokens);
#endif
	return res;
}

static bool FindAndRunWordHelper(const char** token, size_t* tokenNumber, ForthDoStringResult* possibleReturnVal, WordAvailability availability) {
	ReturnValueFromProcessTokenPolicy policy;
	*possibleReturnVal = FindAndRunWord(tokenNumber, token, availability, &policy);
	switch (policy)
	{
	case IfRuntimeError:
		if (*possibleReturnVal == RuntimeError) {
			return true;
		}
		break;
	case Force:
		return true;
		break;
	case IfChangedExecutionPosition:
		if (*possibleReturnVal == ExecutionPositionChangedByWord) {
			return true;
		}
	default:
		break;
	}
	return false;
}

static ForthDoStringResult ProcessToken(const char** token, size_t* tokenNumber) {
	ForthDoStringResult rVal = TokenDoneOkay;
	_nextTokenIsStringLiteral = _parsingStringLiteralFlag;
	if (_parsingStringLiteralFlag) {

		AddToStringLiteralBuffer(*token);
		//return TokenDoneOkay;
	}
	bool currentNestIsReadable = true;
	if (_controlFlowStackSize > 0) {
		currentNestIsReadable = PeekControlFlowStack();
	}
	if (currentNestIsReadable || _compileFlag) {
		if (_commentFlag && _compileFlag) {
			if (FindAndRunWordHelper(token, tokenNumber, &rVal, CommentFlagSet)) {
				return rVal;
			}
		}
		else if (_compileFlag) {
			if (FindAndRunWordHelper(token, tokenNumber, &rVal, CompileFlagSet)) {
				return rVal;
			}
			if (rVal == WordNotFound || ((strcmp(*token, ".\"") == 0) || (strcmp(*token, "s\"") == 0))) {
				CompileToByteCode(*token);
			}

		}
		else {
			int converted = atoi(*token);
			if (strcmp(*token, "0") == 0) {
				if (_settingVariableFlag) {
					_printf("variable flag must be followed by a name");
					return RuntimeError;
				}
				// atoi returns 0 when it can't be converted... so I suppose we need this special case
				PushInt(0);
			}
			else if (converted) {
				if (_settingVariableFlag) {
					_printf("variable flag must be followed by a name");
					return RuntimeError;
				}
				// this token is an integer
				PushInt(converted);
			}
			else if (converted == 0) {
				if (_settingVariableFlag) {
					_settingVariableFlag = false;
					AddIntVariable(*token);
				}
				else {
					if (FindAndRunWordHelper(token, tokenNumber, &rVal, NoFlagsSet)) {
						return rVal;
					}
				}

			}
		}
	}
	else {
		if (_commentFlag == false) {
			if (FindAndRunWordHelper(token, tokenNumber, &rVal, CurrentNestIsNotReadable)) {
				return rVal;
			}
		}
	}
	return TokenDoneOkay;
}

ForthDoStringResult FindAndRunWord(size_t* tokenNumber, char** token, WordAvailability flags, ReturnValueFromProcessTokenPolicy* policyOut) {
	for (int i = _numCompiledWords - 1; i >= 0; i--) {
		CompiledWordInfo* info = _compiledWordsInfos + i;
		*policyOut = info->returnValuePolicy;
		if ((info->availability & flags) == 0) {
			continue;
		}
		if (strcmp(*token, info->name) == 0) {
			if (info->isCFunction) {
				return info->cFunctionPtr(tokenNumber, token);
			}
			else {
				return RunWord(i);
			}
		}
	}
	for (int i = 0; i < _numVariables; i++) {
		if (strcmp(*token, _variables[i].name) == 0) {
			if (PushVariableAddressOntoStack(i) == RuntimeError) return RuntimeError;
			else return WordNotFound;
		}
	}
	//printf("Word not found\n");
	return WordNotFound;
}

ForthDoStringResult DoPreTokenizedString(const char* string, int numTokens) {
	char* token = string;
	for (int i = 0; i < numTokens; i++) {

		ForthDoStringResult res = ProcessToken(&token, &i);
		if (res != TokenDoneOkay && res != ExecutionPositionChangedByWord) {
			return res;
		}
		if (res != ExecutionPositionChangedByWord) {
			token += strlen(token) + 1;
		}
	}
	return StringDoneOkay;
}

static ForthDoStringResult InterpretBytecodeToken(int token, size_t* tokenNumber, WordAvailability flags) {
	char** _ = NULL;
	if (_nextByteCodeValueIsVariable) {
		_nextByteCodeValueIsVariable = false;
		PushVariableAddressOntoStack(token);
	}
	else {
		if (token >= _numCompiledWords || token < 0) {
			_printf("word: %i not found\n", token);
			return RuntimeError;
		}
		if ((_compiledWordsInfos[token].availability & flags) == 0) {
			return TokenDoneOkay; // token has been ignored as it's availability doesn't match current availability - this is Ok
		}
		if (_compiledWordsInfos[token].isCFunction) {
			_compiledWordsInfos[token].cFunctionPtr(tokenNumber, _);
		}
		else {
			DoBytecodeWord(_compiledWordsInfos[token].bytecode, _compiledWordsInfos[token].numTokens);
		}
	}
}

static ForthDoStringResult ProcessBytecodeToken(Cell token, size_t* tokenNumber) {
	ForthDoStringResult rVal = TokenDoneOkay;

	bool currentNestIsReadable = true;
	if (_controlFlowStackSize > 0) {
		currentNestIsReadable = PeekControlFlowStack();
	}
	if (currentNestIsReadable) {

		if (_nextByteCodeValueIsLiteral) {
			if (_settingVariableFlag) {
				_printf("variable flag must be followed by a name");
				return RuntimeError;
			}
			PushInt(token);
			_nextByteCodeValueIsLiteral = false;
		}
		else {
			if (_settingVariableFlag) {
				_settingVariableFlag = false;
				//AddIntVariable(*token);
			}
			else {
				InterpretBytecodeToken(token, tokenNumber, NoFlagsSet);
			}

		}
	}
	else {
		if (!_commentFlag) {
			InterpretBytecodeToken(token, tokenNumber, CurrentNestIsNotReadable);
		}
	}
	return TokenDoneOkay;
}

static ForthDoStringResult DoBytecodeWord(Cell* bytecode, int numTokens) {
	_runningCompiledCode = true;
	Cell lastToken = 0xdeadbeef;
	for (int i = 0; i < numTokens; i++) {
		Cell val = bytecode[i];
		char* name = _compiledWordsInfos[val].name;
		if (_parsingStringLiteralFlag) {
			// parse string literal and skip over the string data to the token on the other side
			int stringSizeCells = bytecode[i++];
			const char* string = (const char*)&bytecode[i];
			AddToStringLiteralBuffer(string);
			i += stringSizeCells - 1;
		}
		else if (((bytecode[i - 1] == STRING_LITERAL_TOKEN) || (bytecode[i - 1] == STRING_LITERAL_WITH_DOT_TOKEN)) &&
			((bytecode[i - 2] != STRING_LITERAL_TOKEN) || (bytecode[i - 1] == STRING_LITERAL_WITH_DOT_TOKEN))) {
			// we're not parsing a string literal but we need to skip over the string data
			int stringSizeCells = bytecode[i++];
			i += stringSizeCells - 1;
		}
		else {
			ProcessBytecodeToken(bytecode[i], &i);
		}
		lastToken = val;
	}
	_runningCompiledCode = false;
	return TokenDoneOkay;
}

#pragma endregion

#pragma region misc helpers

char* SkipStringLiteral(char* nextToken) {

	for (int i = 0; i < STRING_LITERAL_BUFFER_SIZE; i++) {
		if (nextToken[i] == '\"') {
			return nextToken + i;
		}
	}
	return NULL;
}

void AddCFunctionWord(const char* name, CFunctionPtrWord cFunctionPtr, WordAvailability availability, ReturnValueFromProcessTokenPolicy policy) {
	CompiledWordInfo info;
	int baseLength = strlen(name);
	strcpy_s(info.name, baseLength + 1, name);
	info.namelen = baseLength;
	info.isCFunction = true;
	info.cFunctionPtr = cFunctionPtr;
	info.numTokens = 0;
	info.tokenized = false;
	info.returnValuePolicy = policy;
	info.availability = availability;
	_compiledWordsInfos[_numCompiledWords++] = info;
}

#pragma endregion

/* Public functions ************************************************************************************** */

void Forth_Initialise(AllocateHeap allocator, FreeHeap freeAllocated, ReallocateHeap reallocate, ForthPrintf fPrintf)
{
	_intStackTop = _intStack;
	memset(_compiledWordsInfos, 0, sizeof(CompiledWordInfo) * MAX_NUM_COMPILED_WORDS);

	_controlFlowStackTop = _controlFlowStack;
	memset(_controlFlowStack, 0, sizeof(bool) * CONTROL_FLOW_STACK_SIZE);

	_loopStackTop = _loopStack;
	memset(_loopStack, 0, sizeof(LoopInfo) * LOOP_STACK_SIZE);

	_variablesTop = _variables;
	memset(_variables, 0, sizeof(VariableInfo) * MAX_NUM_VARIABLES);

	_stringLiteralBufferEnd = _stringLiteralBuffer;
	memset(_stringLiteralBuffer, 0, STRING_LITERAL_BUFFER_SIZE);

	AddCFunctionWord("literal", &NextTokenIsLiteralWord, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("isvariable", &NextTokenIsVariableWord, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord(".\"", &StartParsingStringWithDot, NoFlagsSet | CompileFlagSet, IfRuntimeError);
	AddCFunctionWord("s\"", &StartParsingString, NoFlagsSet | CompileFlagSet, IfRuntimeError);

	AddCFunctionWord(".", &Dot, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord("show", &PrintIntStack, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("+", &Add, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("-", &Subtract, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("/", &Divide, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("*", &Multiply, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("%", &Modulo, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("pop", &PopWord, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("dup", &Dup, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("twodup", &TwoDup, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("=", &Equal, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("!=", &NotEqual, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("and", &And, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("or", &Or, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord(">", &GreaterThan, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord(">=", &GreaterThanOrEqual, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("<", &LessThan, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("<=", &LessThanOrEqual, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("rot", &Rot, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("swap", &Swap, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord("if", &ifIf, CurrentNestIsNotReadable | NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("then", &ifThen, CurrentNestIsNotReadable | NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("else", &ifElse, CurrentNestIsNotReadable | NoFlagsSet, IfRuntimeError);

	AddCFunctionWord("do", &Do, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("loop", &Loop, NoFlagsSet, IfChangedExecutionPosition);

	AddCFunctionWord("c@", &DereferenceChar, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("c!", &AssignChar, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("!", &Assign, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("@", &Dereference, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord("i", &PushI, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord(":", &StartCompile, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord(";", &EndCompile, CompileFlagSet, IfRuntimeError);

	AddCFunctionWord("(", &StartCommentWord, CompileFlagSet, IfRuntimeError);
	AddCFunctionWord(")", &EndCommentWord, CommentFlagSet, IfRuntimeError);

	AddCFunctionWord("variable", &SetVariableFlagWord, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("compiler", &DebugPrintCompiledWords, NoFlagsSet | CompileFlagSet, IfRuntimeError);

	AddCFunctionWord("cell", &CellsWord, NoFlagsSet, IfRuntimeError);
	AddCFunctionWord("allot", &AllotWord, NoFlagsSet, IfRuntimeError);

	AddCFunctionWord("emit", &EmitWord, NoFlagsSet, IfRuntimeError);

	_alloc = allocator;
	_free = freeAllocated;
	_reallocate = reallocate;
	_printf = fPrintf;
}

ForthDoStringResult Forth_DoString(const char* inputString, int* numTokens)
{
	// don't pass a string literal to this function it won't work the string needs to be assigned to a variable
	char* delim = " ";
	char* nextToken;
	const char* token = strtok_s(inputString, delim, &nextToken);
	while (token != NULL) {
		(*numTokens)++;
		if (strcmp(token, ".\"") == 0 || strcmp(token, "s\"") == 0) {
			char* newNext = SkipStringLiteral(nextToken); // skip the nextToken
			if (newNext == NULL) {
				_printf("you probably forgot the closing \" or you gave a string that was too long to .\"\n");
				return CompileError;
			}
			nextToken = newNext;
		}
		token = strtok_s(NULL, delim, &nextToken);
	}
	// strtok_s modifies the underlying string, so strtok_s the 
	// entire string and work with the result
	return DoPreTokenizedString(inputString, *numTokens);
}

void Forth_Teardown()
{
	for (int i = 0; i < _numVariables; i++) {
		_free(_variables[i].address);
	}
}