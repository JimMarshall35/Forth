// Forth.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <stdio.h>
#include "../Forth/Forth.h"
#include <malloc.h>

#define INPUT_BUFFER_SIZE 10000
static char InputBuffer[INPUT_BUFFER_SIZE];


void Repl() {
    ForthDoStringResult result;
    int numTokens = 0;
    do {
        //memset(InputBuffer, 0, sizeof(int) * INPUT_BUFFER_SIZE);
        printf("[Forth]>>> ");
        gets(InputBuffer);
        result = Forth_DoString(InputBuffer, &numTokens);
        numTokens = 0;
        if (result != StringDoneOkay) {
            printf("Error\n");
        }
    } while (result != ExitRepl);
}
int main()
{
    Forth_Initialise(&malloc, &free, &realloc, &printf, &putchar);
    Repl();
    Forth_Teardown();
}
